package com.capgemini.mps.dao;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.sql.Connection;
import java.sql.SQLException;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.mps.exception.MobilePurchaseException;
import com.capgemini.mps.util.DBConnection;

public class MobileDaoImplTest {

	@BeforeClass
	public static void testDBConnection(){
		
				try {
					Connection connection = DBConnection.getConnection();
					assertNotNull(connection);
				} catch (MobilePurchaseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		@Ignore
		@Test
		public void testDeleteMobile() {
			fail("Not yet implemented");
		}
		@Ignore
		@Test
		public void testGetMobileDetails() {
			fail("Not yet implemented");
		}
		@Ignore
		@Test
		public void testGetMobilesPriceRange() {
			fail("Not yet implemented");
		}

	}
