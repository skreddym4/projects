package com.capgemini.mps.bean;

import java.time.LocalDate;

public class PurchaseDetails {
	private Integer purchaseId;
	private String customerName;
	private String emailId;
	private String	phoneNumber;
	private LocalDate purchaseDate;
	private Integer mobileId;
		
	public PurchaseDetails(){
		
	}

	public PurchaseDetails(int purchaseId, String customerName, String emailId,
			String phoneNumber, LocalDate purchaseDate, Integer mobileId) {
		super();
		this.purchaseId = purchaseId;
		this.customerName = customerName;
		this.emailId = emailId;
		this.phoneNumber = phoneNumber;
		this.purchaseDate = purchaseDate;
		this.mobileId = mobileId;
	}

	public int getPurchaseid() {
		return purchaseId;
	}

	public void setPurchaseid(int purchaseid) {
		this.purchaseId = purchaseid;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String cname) {
		this.customerName = cname;
	}

	public String getMailid() {
		return emailId;
	}

	public void setMailid(String mailid) {
		this.emailId = mailid;
	}

	public String getPhoneno() {
		return phoneNumber;
	}

	public void setPhoneno(String phoneno) {
		this.phoneNumber = phoneno;
	}

	public LocalDate getPurchasedate() {
		return purchaseDate;
	}

	public void setPurchasedate(LocalDate purchasedate) {
		this.purchaseDate = purchasedate;
	}

	public int getMobileid() {
		return mobileId;
	}

	public void setMobileid(int mobileid) {
		this.mobileId = mobileid;
	}

	@Override
	public String toString() {
		return "PurchaseDetails [purchaseId=" + purchaseId + ", customerName="
				+ customerName + ", emailId=" + emailId + ", phoneNumber="
				+ phoneNumber + ", purchaseDate=" + purchaseDate
				+ ", mobileId=" + mobileId + "]";
	}

}
