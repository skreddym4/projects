package com.capgemini.pd.dao;

import com.capgemini.pd.bean.Customer;
import com.capgemini.pd.bean.PizzaOrder;
import com.capgemini.pd.exception.PizzaException;

public interface IPizzaOrderDAO {

	public int placeOrder(Customer customer, PizzaOrder pizza) throws PizzaException;
	public PizzaOrder getOrderDetails(int orderid) throws PizzaException;

}
