package com.capgemini.pd.service;

import com.capgemini.pd.bean.Customer;
import com.capgemini.pd.bean.PizzaOrder;
import com.capgemini.pd.exception.PizzaException;

public interface IPizzaOrderService {
	public int placeOrder(Customer customer,PizzaOrder pizza)throws PizzaException;
	public PizzaOrder getOrderDetails(int orderid)throws PizzaException;

}
