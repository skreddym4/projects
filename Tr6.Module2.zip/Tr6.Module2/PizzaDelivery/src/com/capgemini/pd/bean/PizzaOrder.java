package com.capgemini.pd.bean;

public class PizzaOrder {
	private Integer orderId;
	private Integer customerId;
	private Double totalPrice;
	
	public PizzaOrder(){
		
	}

	public PizzaOrder(Integer orderId, Integer customerId, Double totalPrice) {
		super();
		this.orderId = orderId;
		this.customerId = customerId;
		this.totalPrice = totalPrice;
	}

	public PizzaOrder(int customerId2, double totalPrice2) {
		this.customerId = customerId;
		this.totalPrice = totalPrice;
		}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(Double totalPrice) {
		this.totalPrice = totalPrice;
	}

	@Override
	public String toString() {
		return "PizzaOrder [orderId=" + orderId + ", customerId=" + customerId
				+ ", totalPrice=" + totalPrice + "]";
	}

}
