package com.capgemini.pizza.dao;

import com.capgemini.pizza.exception.PizzaException;

public interface ICustomerDAO {
	public abstract Long addCustomerDetails(String customerName,String address,Long phoneNumber,Double totalPrice,Integer quantity)throws PizzaException; 
}
