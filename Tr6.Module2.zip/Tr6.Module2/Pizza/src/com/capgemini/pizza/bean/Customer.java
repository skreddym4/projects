package com.capgemini.pizza.bean;

public class Customer {
	private Long customerId;
	private String customerName;
	private String address;
	private Long phoneNumber;
	
	public Customer() {
		super();
	}

	public Customer(Long customerId, String customerName, String address,
			Long phoneNumber) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.address = address;
		this.phoneNumber = phoneNumber;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	@Override
	public String toString() {
		return "Customer "
				+ "customerId=" + getCustomerId() + ", "
				+ "customerName="+ getCustomerName() + ", "
				+ "address=" + getAddress() + ","
				+ " phoneNumber="+ getPhoneNumber() + "]";
	}
	
	
}
