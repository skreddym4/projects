package com.capgemini.dd.service;

import com.capgemini.dd.bean.DemandDraft;

public interface IDemandDraftService {
	
	public int addDemandDraftDetails(DemandDraft demandDraft);
	public DemandDraft getDemandDraftDetails(int transactionId);
	

}
