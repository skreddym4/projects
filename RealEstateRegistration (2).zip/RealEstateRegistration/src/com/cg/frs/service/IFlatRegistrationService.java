package com.cg.frs.service;

import java.util.ArrayList;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatRegistrationException;

public interface IFlatRegistrationService {
	public abstract FlatRegistrationDTO registerFalt(FlatRegistrationDTO flat) throws FlatRegistrationException;
	public abstract ArrayList<Integer> getOwnerIds() throws FlatRegistrationException;
}
