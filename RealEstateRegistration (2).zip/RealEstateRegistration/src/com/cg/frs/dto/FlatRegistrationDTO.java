package com.cg.frs.dto;

public class FlatRegistrationDTO {
    private Long flat_reg_no;
    private Integer owner_id;
    private Integer flat_type;
    private Integer flat_area;
    private Double rent_amount;
    private Double deposit_amount;
	public FlatRegistrationDTO() {
		super();
	}
	
	public FlatRegistrationDTO(Integer owner_id, Integer flat_type,
			Integer flat_area, Double rent_amount, Double deposit_amount) {
		super();
		this.owner_id = owner_id;
		this.flat_type = flat_type;
		this.flat_area = flat_area;
		this.rent_amount = rent_amount;
		this.deposit_amount = deposit_amount;
	}

	public FlatRegistrationDTO(Long flat_reg_no, Integer owner_id,
			Integer flat_type,  Integer flat_area,Double rent_amount,
			Double deposit_amount) {
		super();
		this.flat_reg_no = flat_reg_no;
		this.owner_id = owner_id;
		this.flat_type = flat_type;
		this.flat_area = flat_area;
		this.rent_amount = rent_amount;
		this.deposit_amount = deposit_amount;
	}
	public Long getFlat_reg_no() {
		return flat_reg_no;
	}
	public void setFlat_reg_no(Long flat_reg_no) {
		this.flat_reg_no = flat_reg_no;
	}
	public Integer getOwner_id() {
		return owner_id;
	}
	public void setOwner_id(Integer owner_id) {
		this.owner_id = owner_id;
	}
	public Integer getFlat_type() {
		return flat_type;
	}
	public void setFlat_type(Integer flat_type) {
		this.flat_type = flat_type;
	}
	public Integer getFlat_area() {
		return flat_area;
	}
	public void setFlat_area(Integer flat_area) {
		this.flat_area = flat_area;
	}
	public Double getRent_amount() {
		return rent_amount;
	}
	public void setRent_amount(Double rent_amount) {
		this.rent_amount = rent_amount;
	}
	public Double getDeposit_amount() {
		return deposit_amount;
	}
	public void setDeposit_amount(Double deposit_amount) {
		this.deposit_amount = deposit_amount;
	}
	@Override
	public String toString() {
		return "FlatRegistrationDTO.."
				+ "flat_reg_no=" + getFlat_reg_no()
				+ ", owner_id=" + getOwner_id() + 
				 ", flat_type=" + getFlat_type()
				+ ", flat_area=" + getFlat_area()+ ","
				+ " rent_amount=" + getRent_amount()
				+ ", deposit_amount=" + getDeposit_amount();
	}
    
}
