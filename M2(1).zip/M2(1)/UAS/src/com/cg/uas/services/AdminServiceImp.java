package com.cg.uas.services;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.ProgramsOffered;
import com.cg.uas.bean.ScheduledPrograms;
import com.cg.uas.dao.AdminDaoImp;
import com.cg.uas.dao.IAdminDao;
import com.cg.uas.exception.UserException;

public class AdminServiceImp implements IAdminService {
	IAdminDao dao = null;

	@Override
	public boolean adminlogin(String adminusername, String adminpassword)
			throws UserException {
		dao = new AdminDaoImp();
		return dao.adminlogin(adminusername, adminpassword);
	}

	@Override
	public int addnewprogramschedulesdetails(ScheduledPrograms scheduledPrograms)
			throws UserException {
		dao = new AdminDaoImp();
		return dao.addnewprogramschedulesdetails(scheduledPrograms);
	}

	@Override
	public int addnewprogram(ProgramsOffered programsoffered)
			throws UserException {
		dao = new AdminDaoImp();
		return dao.addnewprogram(programsoffered);
	}

	@Override
	public int deleteprogram(String deleteprogram) throws UserException {
		dao = new AdminDaoImp();
		return dao.deleteprogram(deleteprogram);
	}

	IAdminDao admindao = null;

	@Override
	public String deletescheduledprogram(int programcode) throws UserException {
		admindao = new AdminDaoImp();
		return admindao.deletescheduledprogram(programcode);
	}

	@Override
	public ArrayList<ApplicantBean> listofAcceptedOrRejectedList(String string)
			throws UserException {
		admindao = new AdminDaoImp();
		return admindao.listofAcceptedOrRejectedList(string);
	}

	@Override
	public ArrayList<ApplicantBean> viewallprogramsbyadmin() throws SQLException, UserException {
		admindao=new AdminDaoImp();
		return admindao.viewallprogramsbyadmin();
	}

	@Override
	public boolean SetCutOffPercentage(int percentage) throws SQLException, UserException {
		admindao=new AdminDaoImp();
		return admindao.SetCutOffPercentage(percentage);
	}

	public boolean isvalidProgramName(String newprogram) {
    Pattern newprogramPattern=Pattern.compile("^[A-Za-z ]{1,30}$");
    Matcher newprogramMatcher=newprogramPattern.matcher(newprogram);
    
		return newprogramMatcher.matches();
	}

	public boolean isvalidDescription(String programdescription) {
		 Pattern newprogramPattern=Pattern.compile("^[A-Za-z ]{1,30}$");
		    Matcher newprogramMatcher=newprogramPattern.matcher(programdescription);
		    
		return newprogramMatcher.matches();
	}

	public boolean isvalidDuration(String newduration1) {
		//String string=Integer.toString(newduration);
		 Pattern newprogramdurationPattern=Pattern.compile("^\\d*[1-9]\\d*${1,2}");
		   Matcher newprogramMatcher=newprogramdurationPattern.matcher(newduration1);
//		try{
//			int duration=Integer.parseInt(newduration);
//			return true;
//			
//		}catch(Exception e){
//			return false;
//		}
		return newprogramMatcher.matches();
		
	}

	public boolean isvalidCertificationOffered(String newprogramCO) {
		 Pattern newprogramPattern=Pattern.compile("^[A-Za-z ]{5,30}$");
		    Matcher newprogramMatcher=newprogramPattern.matcher(newprogramCO);
		    
		return newprogramMatcher.matches();
	}

	public boolean isValidApplicationId(int scheduledprogramid) {
		return (scheduledprogramid>1);
	}

//	public boolean isValidDeleteProgram(String deleteprogramname) {
//		Pattern newprogramPattern=Pattern.compile("^[A-Za-z0-9 ]{1,}");
//	    Matcher newprogramMatcher=newprogramPattern.matcher(deleteprogramname);
//		return newprogramMatcher.matches();
//	}

	public boolean isValidScheduledProgramId(int newscheduledprogramid) {
		String string=Integer.toString(newscheduledprogramid);
		 Pattern newprogramPattern=Pattern.compile("[0-9]{3,}");
		    Matcher newprogramMatcher=newprogramPattern.matcher(string);
		return newprogramMatcher.matches();
	}

	public boolean isvalidProgramLocation(String newprogramlocation) {
		Pattern newprogramPattern=Pattern.compile("^[A-Za-z ]{2,30}");
	    Matcher newprogramMatcher=newprogramPattern.matcher(newprogramlocation);
		return newprogramMatcher.matches();
	}

	public boolean isvalidWeeks(int newprogramweeks) {
			return (newprogramweeks>1);
	}

	@Override
	public ArrayList<ProgramsOffered> listOfPrograms() {
	dao=new AdminDaoImp();
		return dao.listOfPrograms();
	}

}
