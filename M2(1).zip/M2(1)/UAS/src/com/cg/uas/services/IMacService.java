package com.cg.uas.services;

import java.util.ArrayList;

import com.cg.uas.bean.ApplicantBean;

public interface IMacService {
public boolean maclogin(String macusername, String macpassword);
public ArrayList<ApplicantBean> scheduledprogram(int programs);
public String macstatusupdate(int applicationid,String statusafterinterview);

}
