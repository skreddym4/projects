
package com.cg.uas.services;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.dao.IMacDao;
import com.cg.uas.dao.MacDaoImp;

public class MacServiceImp implements IMacService {
   IMacDao dao=null;
	@Override
	
	public boolean maclogin(String macusername,String macpassword) {
		dao= new MacDaoImp();
		
		return dao.maclogin(macusername,macpassword);
	}
	 
	@Override
	public ArrayList<ApplicantBean> scheduledprogram(int program) {
		dao=new MacDaoImp();
		return dao.scheduledprograms(program);
	}
	@Override
	public String macstatusupdate(int application, String statusafterinterview) {
		dao=new MacDaoImp();
		return dao.macstatusupdate(application, statusafterinterview) ;
	}

	public boolean isvalidApplicationId(Integer applicationid) {
		String string=Integer.toString(applicationid);
		Pattern applicationidPattern=Pattern.compile("[0-9]{3,}");
		Matcher applicationidMatcher=applicationidPattern.matcher(string);
		return applicationidMatcher.matches();
	}

	public boolean isValidProgramCode(int program) {
		String string=Integer.toString(program);
		Pattern programCodePattern=Pattern.compile("[0-9]{3,}");
		Matcher programCodeMatcher=programCodePattern.matcher(string);
		return programCodeMatcher.matches();
	}	

}
