package com.cg.uas.bean;

import java.sql.Date;

public class ScheduledPrograms {
private String program_name;
public String getProgram_name() {
	return program_name;
}
public void setProgram_name(String program_name) {
	this.program_name = program_name;
}
public int getScheduled_program_id() {
	return scheduled_program_id;
}
public void setScheduled_program_id(int scheduled_program_id) {
	this.scheduled_program_id = scheduled_program_id;
}


public ScheduledPrograms(String program_name, int scheduled_program_id,
		 int sessions_per_week,String location,Date start_date,Date end_date) {
	super();
	this.program_name = program_name;
	this.scheduled_program_id = scheduled_program_id;
	this.start_date = start_date;
	this.end_date=end_date;
	
this.location=location;
	this.sessions_per_week = sessions_per_week;
}






public int getSessions_per_week() {
	return sessions_per_week;
}
public void setSessions_per_week(int sessions_per_week) {
	this.sessions_per_week = sessions_per_week;
}
private int scheduled_program_id;

private Date start_date;
public Date getStart_date() {
	return start_date;
}
public void setStart_date(Date start_date) {
	this.start_date = start_date;
}
public Date getEnd_date() {
	return end_date;
}
public void setEnd_date(Date end_date) {
	this.end_date = end_date;
}
private Date end_date;



private int sessions_per_week;
private String location;

public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
public ScheduledPrograms(){
	
}
}
