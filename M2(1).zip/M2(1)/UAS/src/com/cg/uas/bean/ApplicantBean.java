package com.cg.uas.bean;

import java.sql.Date;

public class ApplicantBean {
	private int scheduledprogramid;
	
	
	public int getScheduledprogramid() {
		return scheduledprogramid;
	}
	public void setScheduledprogramid(int scheduledprogramid) {
		this.scheduledprogramid = scheduledprogramid;
	}
	private String username;
 
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public long getDob() {
		return dob;
	}
	public void setDob(long dob) {
		this.dob = dob;
	}
	public float getMarks() {
		return marks;
	}
	public void setMarks(float marks) {
		this.marks = marks;
	}
	public String getGoals() {
		return goals;
	}
	public void setGoals(String goals) {
		this.goals = goals;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	private String qualification;
	private long dob;
	private float marks;
	private String goals;
	private String emailid;
	
	
	private String status;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getDate_of_interview() {
		return date_of_interview;
	}
	public void setDate_of_interview(Date date_of_interview) {
		this.date_of_interview = date_of_interview;
	}
	public int getApplicationid() {
		return applicationid;
	}
	public void setApplicationid(int applicationid) {
		this.applicationid = applicationid;
	}
	private Date date_of_interview;
	private int applicationid;
	
	
	
	public ApplicantBean(){
		
	}
	public ApplicantBean(String username, String qualification, long dob,
			float marks, String goals, String emailid,int scheduledprogramid,Date date_of_interview,int applicationid,String status) {
		
		this.username = username;
		this.qualification = qualification;
		this.dob = dob;
		this.marks = marks;
		this.goals = goals;
		this.emailid = emailid;
		//this.program=program;
		this.scheduledprogramid=scheduledprogramid;
		this.date_of_interview=date_of_interview;
		this.status=status;
		this.scheduledprogramid=scheduledprogramid;
	}
	

}
