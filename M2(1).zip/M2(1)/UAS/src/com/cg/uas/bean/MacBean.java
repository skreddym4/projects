package com.cg.uas.bean;

public class MacBean {
private String macusername;
public String getMacusername() {
	return macusername;
}
public void setMacusername(String macusername) {
	this.macusername = macusername;
}
public String getMacpassword() {
	return macpassword;
}
public void setMacpassword(String macpassword) {
	this.macpassword = macpassword;
}
private String macpassword;

public MacBean(String macusername,String macpassword){
	this.macusername=macusername;
	this.macpassword=macpassword;
}
 public MacBean(){
	
}
}
