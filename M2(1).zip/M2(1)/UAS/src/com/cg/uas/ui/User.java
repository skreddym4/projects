package com.cg.uas.ui;

//import java.sql.Date;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

//import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.MacBean;
import com.cg.uas.bean.ProgramsOffered;
import com.cg.uas.bean.ScheduledPrograms;
import com.cg.uas.exception.UserException;
import com.cg.uas.services.AdminServiceImp;
import com.cg.uas.services.ApplicantService;
import com.cg.uas.services.IAdminService;
import com.cg.uas.services.IApplicantService;
import com.cg.uas.services.IMacService;
import com.cg.uas.services.MacServiceImp;
import org.apache.log4j.*;

public class User {
	static Logger logger = Logger.getRootLogger();
	static ApplicantService applicantService = new ApplicantService();
	static MacServiceImp imacservice = new MacServiceImp();
	static AdminServiceImp adminService = new AdminServiceImp();
	static// static ApplicantService service = new ApplicantService();
	ArrayList<ApplicantBean> specificprogram = null;
	static ArrayList<ApplicantBean> listofallaplication = new ArrayList<>();
	static Scanner scanner;
	static ArrayList<ProgramsOffered> lisofprogrmasArrayList = new ArrayList<>();
	static BufferedReader buffered = new BufferedReader(new InputStreamReader(
			System.in));

	public static void main(String[] args) throws ParseException, IOException {

		scanner = new Scanner(System.in);

		startTheProgram();
	}

	// =================START PROGRAM=========================================
	private static void startTheProgram() throws ParseException, IOException {

		String dummy = "";
		do {
			System.out.println("====================================");
			System.out.println("    WELCOME TO JNTU UNIVERSITY      ");
			System.out.println("====================================");

			System.out.println();
			System.out.println("========OPTIONS=======");
			System.out.println();

			System.out.println("1.Proceed As Student");
			System.out.println("2.Proceed As ADMIN");
			System.out.println("3.Proceeed As MAC");
			System.out.println("4.Exit");
			System.out.println("Please Choose Option:");
			int option = 0;

			int forward = 0;
			dummy = scanner.next();
			for (int i = 1; i < 5; i++) {
				if (dummy.equals(Integer.toString(i))) {
					forward = 1;
					break;
				}
			}

			if (forward == 1) {
				option = Integer.parseInt(dummy);
				switch (option) {

				// 1. Apply For Program As Student

				case 1:
					proceedAsStudent();
					break;

				case 2:
					try {
						proceedAsAdmin();
						startTheProgram();
					} catch (UserException e) {

						e.printStackTrace();
					}
					break;

				case 3:
					tryLoginForMAC();
					break;

				case 4:
					System.err.println("You logged out");
					logger.error("Wrong input by user");
					startTheProgram();
					break;

				default:
					System.err.println("Please Choose Correct Option:");
					System.out.println("Thank You");
					logger.error("wrong input by user");
					startTheProgram();
				}

			} else {
				System.err.println("Wrong input");
				logger.error("Wrong Input Entered By User");
			}

		} while (!dummy.equals("4"));
	}

	// ===================ADMIN USERNAME AND PASSWORD VALIDATIONS=========
	private static void proceedAsAdmin() throws ParseException, UserException,
			IOException {

		boolean isValidUser = tryLoginAsAdmin();

		if (isValidUser) {
			logger.info("Username and password are correct");
			showAdminOperations();
		}

		else {
			System.err.println("Wrong Admin Credentials");
			logger.error("Wrong username or password Entered By User");
			startTheProgram();
		}
	}

	// ==============ADMIN OPERATIONS====================================
	private static void showAdminOperations() throws ParseException,
			UserException, IOException {
		String dummy = "";
		do {
			System.out.println("====================================");
			System.out.println("WELCOME TO ADMIN OPERATIONS SECTIONS");
			System.out.println("====================================");
			System.out.println();

			System.out.println("");
			System.out.println("1.Add  New Prgram :");
			System.out.println("2.Delete Program:");
			System.out.println("3.Add Scheduled Program");
			System.out.println("4.Delete Scheduled Program");

			System.out.println("5.List Of Applicants Confirmed/Rejected");
			System.out.println("6.View All Applications");
			System.out.println("7.Set Set CutOff Percentage");
			System.out.println("8.Exit");
			System.out.println();
			System.out.println("Choose Operation:");
			System.out.println();
			int adminoption = 0;

			int forward = 0;
			dummy = scanner.next();
			for (int i = 1; i < 9; i++) {
				if (dummy.equals(Integer.toString(i))) {
					forward = 1;
					break;
				}
			}
			if (forward == 1) {
				adminoption = Integer.parseInt(dummy);
				switch (adminoption) {
				case 1:

					AddProgramMacOperation();
					showAdminOperations();
					break;
				case 2:
					deleteprogram();
					showAdminOperations();
					break;
				case 3:

					addScheduledProgram();
					showAdminOperations();
					break;
				case 4:
					deletescheduledprogram();
					showAdminOperations();
					break;
				case 5:
					listofacceptedorrejected();
					showAdminOperations();
					break;
				case 6:
					viewallapplications();
					showAdminOperations();

				case 7:
					SetcuOffMarks();
					showAdminOperations();
					break;

				case 8:
					System.err.println("You Are Logged Out");
					logger.info("User Logged Out");
					startTheProgram();
				}
			} else {
				System.err.println("Wrong Input");
				logger.error("User Entered Entered Wrong Choice");
			}
		} while (!dummy.equals("8"));
	}

	// ==================SETTING CUT OFF MARKS BY ADMIN=========
	private static void SetcuOffMarks() {
		boolean statusofcutmark = false;
		System.out.println("Enter Cut Off Percentage: ");
		int cutoffmark = 0;

		// ==================validating percentage=================
		try {
			cutoffmark = scanner.nextInt();
		} catch (InputMismatchException e) {
			logger.error("input mismatch happened");
			scanner.nextLine();
			System.err.println("Invalid Input");
		}
		while (true) {
			if (cutoffmark < 100 && cutoffmark > 0)

				break;
			else {
				System.err.println("Invalid Percentage, Try Again");
				logger.error("Invalid percentage Entered by user ");
				System.out.println("Enter Valid Percentage:");
				try {
					cutoffmark = scanner.nextInt();
				} catch (InputMismatchException e) {
					logger.error("input mismatch happened");
					scanner.nextLine();
					System.err.println("invalid Input");
				}
			}
		}

		try {
			statusofcutmark = adminService.SetCutOffPercentage(cutoffmark);
			//System.out.println(statusofcutmark);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Sql executed");
			logger.error("input mismatch happened");
			e.printStackTrace();
		} catch (UserException e) {
			System.out.println("User Defined executed");
			logger.error("input mismatch happened");
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (statusofcutmark == true) {
			System.out.println("=========================");
			System.out.println("   UPDATED SUCCESSFULLY  ");
			System.out.println("=========================");
			logger.info("Details Are Updated Successfully");
		} else {
			System.err.println("===========================================");
			System.err.println("  SOMETHING WENT WRONG PLEASE DO IT AGAIN  ");
			System.err.println("===========================================");
			System.out.println();
			logger.info("No Details Are Added ");
		}
	}

	// ==================ALL APPLICATIONS================
	private static void viewallapplications() {
		System.out.println("=======================");
		System.out.println("    ALL APPLICATIONS   ");
		System.out.println("=======================");
		System.out.println();
		try {

			listofallaplication = adminService.viewallprogramsbyadmin();
			if (listofallaplication != null) {

				for (ApplicantBean bean : listofallaplication) {
					System.out.println("Application_id: "
							+ bean.getApplicationid() + " "
							+ "Applicant_Name :" + bean.getUsername() + " "
							+ "Applicant_date_of_birth: " + bean.getDob() + " "
							+ "Applicant_highest_qualification: "
							+ bean.getQualification() + " "
							+ "Applicant_marks: " + bean.getMarks() + " "
							+ "Applicant_Goals: " + bean.getGoals() + " "
							+ "Applicant EI: " + bean.getEmailid() + " "
							+ "Applicant SPI: " + bean.getScheduledprogramid()
							+ " " + "Applicant Status: " + bean.getStatus());
				}
			} else {
				System.err.println("=============================");
				System.err.println("NO APPLICATIONS ARE AVAILABLE");
				System.err.println("=============================");
			}
		} catch (SQLException e) {

			e.printStackTrace();
		} catch (UserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	// ==========LIST OF ACCEPTED OR REJECTED LIST===========
	// ==================LIST OF ACCEPTED OR REJECTED APPLIATIONS======
	private static void listofacceptedorrejected() throws UserException {

		ArrayList<ApplicantBean> list = new ArrayList<>();
		System.out.println("Enter Accepted or Rejected");
		String statusString = scanner.next();
		if (statusString.equals("Accepted") || statusString.equals("Rejected")) {

			list = adminService.listofAcceptedOrRejectedList(statusString);
			if (list == null) {
				System.out.println("List Was Empty");
			} else {
				System.out.println("==================");
				System.out.println("LIST OF APPLICANTS");
				System.out.println("==================");
				System.out.println();
				for (ApplicantBean bean : list) {
					System.out.println("LIST:" + bean.getApplicationid());

				}

			}

		} else {
			System.err.println("Enter Accepted or Rejected Only!!!");
			listofacceptedorrejected();
		}
	}

	// ===================DELETING SCHEDULED PROGRAM====

	// ============DELETE SCHEDULED PROGRAM================

	private static void deletescheduledprogram() throws UserException {
		System.out.println("==================================");
		System.out.println("   Availabel Scheduled Program Id's ");
		System.out.println("==================================");

		System.out.println();
		applicantService.displayprogramsschedule();
		System.out.println();
		System.out.println("Enter Scheduled Program Id Want To Delete:");
		System.out.println();
		System.err.println("Refere First Column For Id's");
		int scheduledprogramid = 0;
		// =============Application Id Validations==============
		try {
			scheduledprogramid = scanner.nextInt();
		} catch (InputMismatchException e) {
			scanner.nextLine();
			System.err.println("Invalid Input!!");
		}
		while (true) {
			if (adminService.isValidApplicationId(scheduledprogramid))
				break;
			else {
				System.err
						.println("Application Id Should Be 3 Digit Only!!, Try Again");
				System.out
						.println("Enter Scheduled Program Id Want To Delete:");
				try {

					scheduledprogramid = scanner.nextInt();
				} catch (InputMismatchException e) {
					scanner.nextLine();
					System.err.println("Enter Numerics Only!!");

				}
			}
		}
		applicantService.displayprogramsschedule();
		String statusString = adminService
				.deletescheduledprogram(scheduledprogramid);
		if (statusString != null) {
			System.out.println("====================================");
			System.out.println(statusString);
			System.out.println("====================================");
		} else {
			System.out.println("====================================");
			System.err.println(statusString);
			System.out.println("====================================");

		}
	}

	// ==================DELETING PROGRAM BY ADMIN============

	// ===========DELETE UNIVERSITY PROGRAMS============
	private static void deleteprogram() throws ParseException, UserException,
			IOException {
		String deleteprogramname = "";

		// System.out.println("Available Prgrams Names Are:");
		System.out.println();

		adminService.listOfPrograms();
		System.out.println();
		System.out.println("Enter The Course Name To Delete:");
		System.out.println();
		deleteprogramname = buffered.readLine();
		while (true) {
			if (adminService.isvalidDescription(deleteprogramname))
				break;
			else {
				System.err.println("Enter Characters Only!!!");

				try {
					deleteprogramname = buffered.readLine();
				} catch (InputMismatchException e) {
					scanner.nextLine();
					System.err.println("Enter Characters Only!!!");
				}
			}
		}
		adminService = new AdminServiceImp();
		adminService.deleteprogram(deleteprogramname);
		showAdminOperations();
	}

	// ====================ADDING NEW SCHEDULED PROGRAM ==================
	private static void addScheduledProgram() throws ParseException,
			UserException, IOException {
		System.out.println();
		System.out.println("================================");
		System.out.println("   NEW SCHEDULED PROGRAM FORM   ");
		System.out.println("================================");
		System.out.println();
		System.out.println("Enter The Program Name:");
		String newprogramname = buffered.readLine();
		// ==========Name Validations============
		while (true) {
			if (adminService.isvalidProgramName(newprogramname))
				break;
			else {
				System.err
						.println("Program Name Should Be Characters && Less Than 30 Characters && Greater Than 2 Characters");
				System.out.println("Enter The name Of Program:");
				try {
					newprogramname = buffered.readLine();
				} catch (InputMismatchException e) {
					scanner.next();
					System.err.println("Enter Characters only!!!!");

				}
			}
		}

		// =============Application Id Validations==============
		System.out.println("Enter the Scheduled Program Id:");
		int newscheduledprogramid = 0;
		// newscheduledprogramid = scanner.nextInt();
		try {
			newscheduledprogramid = scanner.nextInt();
		} catch (InputMismatchException e) {
			scanner.nextLine();
			System.err.println("Invalid Input!!");
		}
		while (true) {
			if (adminService.isValidScheduledProgramId(newscheduledprogramid))
				break;
			else {
				System.err
						.println("Application Id Should Be Numerics Only && Greater Than 2 Digit Only!!, Try Again");
				System.out.println("Enter the Scheduled Program Id:");
				try {

					newscheduledprogramid = scanner.nextInt();
				} catch (InputMismatchException e) {
					scanner.nextLine();
					System.err.println("Enter Numerics Only!!");

				}
			}
		}

		// ============Location validation============
		System.out.println("Enter Program Location:");
		String newprogramlocation = "";
    boolean location=false;
		newprogramlocation = buffered.readLine();
		while (!location) {
			if (adminService.isvalidProgramLocation(newprogramlocation)){
				location=true;
			}
			else {
				System.err
						.println("Location Should Be Characters && It Should Be Less Than 30 And Greater 5 Characters Only!!");
				
				System.out.println("Enter Program Location:");
			
				
					newprogramlocation = buffered.readLine();

				}
			}
		
		// ==============Date Validations==============================
		System.out
				.println("Enter The Start Date For Program In The Format dd-mm-yyyy:");

		String newprogramstartdate = "";
		java.sql.Date sqlStartDate = null;
		int flag = 0;

		boolean isValidDate = false;

		while (!isValidDate) {

			try {
				newprogramstartdate = scanner.next();
				SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
				java.util.Date date1 = sdf1.parse(newprogramstartdate);
				sqlStartDate = new java.sql.Date(date1.getTime());
				isValidDate = true;

			} catch (InputMismatchException e) {
				System.err.println("Invalid Input!!");

			} catch (ParseException r) {
				System.err.println("Invalid Input");
			}

		}

		// =======endDtae validations=============
		System.out
				.println("Enter The End Date For Program In The Format dd-MM-yyyy:");
		String newprogramendate = "";
		java.util.Date date2;
		boolean isValidEndDate = false;
		java.sql.Date sqlendDate = null;
		while (!isValidEndDate) {
			try {
				newprogramendate = scanner.next();
				SimpleDateFormat sdf2 = new SimpleDateFormat("dd-MM-yyyy");

				date2 = sdf2.parse(newprogramendate);
				sqlendDate = new java.sql.Date(date2.getTime());
				isValidEndDate = true;
			} catch (InputMismatchException e) {
				System.err.println("invalid input");

			} catch (ParseException e) {
				System.err.println("Invalid Input");

			}
		}
		// ==================Weeks validations============

		System.out.println("Enter The No Of Sessions Per Week:");
		int newprogramweeks = 0;
		boolean weeks2=false;
		String weeks = buffered.readLine();
		while (!weeks2) {

			if (adminService.isvalidDuration(weeks)) {
				newprogramweeks = Integer.parseInt(weeks);
				weeks2 = true;

			} else {
				System.err.println("Invalid Input, Try Again");
				System.out.println("Enter Duration( In Weeks):");
				weeks = buffered.readLine();
			}
		}
		ScheduledPrograms scheduledPrograms = new ScheduledPrograms();

		scheduledPrograms.setScheduled_program_id(newscheduledprogramid);
		scheduledPrograms.setProgram_name(newprogramname);
		scheduledPrograms.setStart_date(sqlStartDate);
		scheduledPrograms.setEnd_date(sqlendDate);
		scheduledPrograms.setLocation(newprogramlocation);
		scheduledPrograms.setSessions_per_week(newprogramweeks);

		adminService = new AdminServiceImp();
		int status1 = adminService
				.addnewprogramschedulesdetails(scheduledPrograms);
		if (status1 != 0) {

			System.out.println("==========================");
			System.out.println("SUCCESSFULLY ADDED DEATILS");
			System.out.println("===========================");
			System.out.println("");
			System.out.println("New Program Details Are Added With Id:"
					+ status1);
			logger.info("Details Are Added Successfully ");
		} else {
			System.err.println("==========================");
			System.err.println("NOT ADDED TO THE DATABASE");
			System.err.println("==========================");
			System.out.println();
			System.out.println("================");
			System.out.println("   THANK YOU    ");
			System.out.println("================");
			System.out.println();
		}
	}

	// =====================ADDING NEW UNIVERSITY PROGRAM===========
	private static void AddProgramMacOperation() throws UserException,
			IOException {
		System.out.println("================================");
		System.out.println("     NEW PROGRAM FORM           ");
		System.out.println("================================");
		System.out.println();
		System.out.println("Enter The name Of Program:");
		String newprogram = buffered.readLine();
		boolean dummy2 = false;
		// ==========Name Validations============
		while (!dummy2) {
			if (adminService.isvalidProgramName(newprogram)) {
				dummy2 = true;
			} else {
				System.err
						.println("Program Name Should Be Characters And Greater Than 1 and less than 30! ");

				System.out.println("Enter The name Of Program:");
				newprogram = buffered.readLine();
			}
		}
		// =================Description validations================
		System.out.println("Enter Description For Program:");
		String programdescription = buffered.readLine();
		boolean dummy1 = false;
		while (!dummy1) {
			if (adminService.isvalidDescription(programdescription)) {
				dummy1 = true;
			} else {
				System.err
						.println(" Invalid Input, Description Should Be Less Than 30 And Greater Than 1");
				System.out.println("Enter Description For Program:");

				programdescription = buffered.readLine();

			}
		}
		// ======================Eligibility Validations==============
		System.out.println("Enter Applicant Eligibility:");
		String newprogramapplicanteligibility = buffered.readLine();
		boolean dummy = false;
		while (!dummy) {
			if (adminService.isvalidDescription(newprogramapplicanteligibility)) {
				dummy = true;
			} else {
				System.err
						.println(" Invalid Input, Eligibility Should Be Less Than 30 And Greater Than 5");
				System.out.println("Enter Applicant Eligibility:");

				newprogramapplicanteligibility = buffered.readLine();
			}
		}
		// ==============Duration Validations========================

		System.out.println("Enter Duration( In Weeks):");
		String newduration1 = "";
		int newduration = 0;
		newduration1 = buffered.readLine();
		boolean dur = false;
		while (!dur) {

			if (adminService.isvalidDuration(newduration1)) {
				newduration = Integer.parseInt(newduration1);
				dur = true;

			} else {
				System.err.println("Invalid Input, Try Again");
				System.out.println("Enter Duration( In Weeks):");
				newduration1 = buffered.readLine();
			}
		}
		// ============validations for certificate===========
		System.out.println("Enter Certificate Offered:");
		String newprogramCO = "";
		newprogramCO = buffered.readLine();
		boolean dummy4 = false;
		while (!dummy4) {
			if (adminService.isvalidCertificationOffered(newprogramCO)) {
				dummy4 = true;
			}

			else {
				System.err
						.println("Certificate Offered Sholud Be Less than 30 And Greater Than 5 Characters Only!!");

				System.out.println("Enter Program Description");
				newprogramCO = buffered.readLine();
			}
		}
		ProgramsOffered programsoffered = new ProgramsOffered();
		programsoffered.setProgramName(newprogram);
		programsoffered.setProgramDescription(programdescription);
		programsoffered.setDuration(newduration);
		programsoffered.setDegreeCertificationOffered(newprogramCO);
		programsoffered
				.setApplicationEligibility(newprogramapplicanteligibility);
		adminService = new AdminServiceImp();
		int status2 = adminService.addnewprogram(programsoffered);
		System.out.println("======================================");
		System.out.println("    DETAILS ARE SUCCESSFULLY  ADDED   ");
		System.out.println("======================================");
		System.out.println("");
		System.out.println("details are added with:" + status2);
		System.out.println();
		System.out.println("================");
		System.out.println("   THANK YOU    ");
		System.out.println("================");
		System.out.println();
	}

	// ===================LOGIN PAGE FOR ADMIN===========
	// =====================LOGIN PAGE FOR ADMIN================

	private static boolean tryLoginAsAdmin() throws UserException,
			ParseException, IOException {

		boolean validUser = false;

		System.out.println("===============================");
		System.out.println("      WELCOME TO ADMIN         ");
		System.out.println("===============================");
		System.out.println();

		System.out.println("Please enter Username:");
		System.out.println("Enter -1 To Go Back");
		String adminusername = scanner.next();

		try {
			Integer.valueOf(adminusername);
			if (Integer.valueOf(adminusername) == -1) {
				startTheProgram();
			}
		} catch (Exception e) {

			System.out.println("Please enter your password");
			String adminpassword = scanner.next();

			boolean status = adminlogin(adminusername, adminpassword);
			if (status == true) {
				System.out.println("=======================");
				System.out.println("Login Successfully!!!");
				System.out.println("=======================");
				System.out.println("");

				validUser = true;

			} else {
				System.err.println("=======================");
				System.err.println("!!!!!!!Login Failed!!!!");
				System.err.println("=======================");
				System.out.println("");
				System.out.println("Invalid Username Or Password ");
				System.out.println();
				System.out.println("================");
				System.out.println("   THANK YOU    ");
				System.out.println("================");
				System.out.println();
				startTheProgram();
			}
		}
		return validUser;
	}

	// =====================OPTIONS FOR STUDENT===================
	private static void proceedAsStudent() throws ParseException, IOException {
		String dummy = "";
		do {
			System.out.println("=========================");
			System.out.println("  WELCOME TO APPLICANT   ");
			System.out.println("=========================");
			System.out.println();
			System.out.println("Press 1 To Apply For A Program");
			System.out.println("Press 2 To View Your Application Status");
			System.out.println("Press 3 To View Status After Interview");
			System.out.println("Press 4 Exit");
			int choice = 0;

			int forward = 0;

			dummy = scanner.next();
			for (int i = 1; i < 5; i++) {
				if (dummy.equals(Integer.toString(i))) {
					forward = 1;
					break;
				}
			}
			if (forward == 1) {
				choice = Integer.parseInt(dummy);

				switch (choice) {
				case 1:
					applyForProgramAsApplicant();
					startTheProgram();
					break;

				case 2:
					viewApplicationStatusAfterApplication();
					startTheProgram();
					break;
				case 3:
					ViewStatusAfterInterview();
					startTheProgram();
				case 4:
					startTheProgram();
				default:
					startTheProgram();
					break;
				}

			} else {
				System.err.println("Invalid Input");
				logger.info("Wrong Input from User");
			}
		} while (!dummy.equals("4"));
	}

	// =====================STATUS AFTER INTERVIEW FOR STUDENTS=========
	private static void ViewStatusAfterInterview() {

		System.out.println("Enter Application Id");
		Integer applicationid = 0;
		try {
			applicationid = scanner.nextInt();
		} catch (InputMismatchException e) {
			logger.error("Input Mismatch Ocuured");
			System.err.println("Enter Number only!!!!");
		}
		while (true) {
			if (imacservice.isvalidApplicationId(applicationid))
				break;
			else {
				System.err.println("Enter Valid Application Id");
				try {
					applicationid = scanner.nextInt();
				} catch (InputMismatchException e) {
					logger.error("Input Mismatch Occeurd");
					scanner.nextLine();
					// System.err.println("Enter Numeric only!!");
					System.out.println("Enter Application Id");
				}
			}
		}

		String statusofinterview = applicantService
				.StatusAfterinterview(applicationid);
		if (statusofinterview != null) {
			System.out.println();
			System.out.println("Status Of :" + applicationid + " Is :"
					+ statusofinterview);
			logger.info("Status Of Id Was Dosplayed Successfully");
		}
	}

	// =====================APPLICATION FORM FOR STUDENTS===========
	private static void applyForProgramAsApplicant() throws ParseException,
			IOException {

		System.out.println("======================");
		System.out.println("  LIST OF PROGRAMS   ");
		System.out.println("======================");

		System.out.println();
		System.out
				.println("Program || Qualification || Description || Duration || Certification ");
		System.out.println();
		// Displaying The Exisiting Programs
		applicantService.displayall();
		System.out.println();

		System.out.println();
		System.out.println("======================");
		System.out.println("  PROGRAM DETAILS   ");
		System.out.println("======================");
		System.out.println("");

		System.err
				.println("======= For Scheduled Program Id See the First Column====== :");
		System.out.println();
		System.out
				.println("Scheduled Program Id || Program Name || Start Date || End Date || No Of Weeks || Location   ");
		System.out.println();

		// Displaying Program Details

		applicantService.displayprogramsschedule();

		System.out.println();

		// Getting The Student Application

		getApplicationFromStudent(scanner);
		System.out.println();
		startTheProgram();
	}

	// =====================STATUS AFTER APPLICATION FORM FILLING==========
	private static void viewApplicationStatusAfterApplication() {
		System.out.println("===================================");
		System.out.println("  STATUS SECTION AFTER APPLICATION ");
		System.out.println("===================================");
		System.out.println();
		System.out.println("Please Enter Application Id:");
		int applicantid = 0;
		try {
			applicantid = scanner.nextInt();
		} catch (InputMismatchException e) {
			scanner.nextLine();
			System.err.println("Invalid Input");
		}
		while (true) {
			if (applicantService
					.isValidApplicationIdForStatusAfterApplication(applicantid))
				break;
			else {
				System.err.println("Invalid input");
				System.out.println("Please Enter Application Id:");
				try {
					applicantid = scanner.nextInt();
				} catch (InputMismatchException e) {
					scanner.nextLine();
					System.err.println("Invalid Input");
				}
			}
		}
		String statusofapplication = applicantService
				.applicationstatus(applicantid);
		if (statusofapplication != null) {
			
			System.out.println("==============");
			String arr[] = statusofapplication.split(",");
			System.out.println("Status:");
			System.out.println(arr[0]);
			System.out.println("Date Of Interview:");
			System.out.println(arr[1]);
		} else {
			System.err.println("No Data Found");
			System.out.println();
			System.out.println("================");
			System.out.println("   THANK YOU    ");
			System.out.println("================");
			System.out.println();
		}
	}

	// =====================LOGIN PAGE MAC============
	private static void tryLoginForMAC() throws ParseException, IOException {

		System.out.println("===============================");
		System.out.println("      WELCOME TO MAC           ");
		System.out.println("===============================");
		System.out.println("");

		System.out.println("Please enter Username:");
		String macusername = scanner.next();

		System.out.println("Please enter your password");
		String macpassword = scanner.next();

		boolean data = maclogin(macusername, macpassword);
		if (data == true) {
			System.out.println("=======================");
			System.out.println("Login Successfully!!!");
			System.out.println("=======================");
			System.out.println("");
			logger.info("user logged with correct credentials");
			loginAsMAC();

		} else {

			System.err.println("=======================");
			System.err.println("!!!!!!!Login Failed!!!!");
			System.err.println("=======================");
			System.out.println("");
			System.out.println("Please Enter Correct Username Or Password ");
			System.out.println();
			logger.error("Login Failed Due To Incorrect Username And Password");
			System.out.println("================");
			System.out.println("   THANK YOU    ");
			System.out.println("================");
			System.out.println();
		}
		startTheProgram();
	}

	// =====================OPTIONS FOR MAC==========
	private static void loginAsMAC() throws ParseException, IOException {
		// TODO Auto-generated method stub
		String dummy = "";
		do {

			System.out.println("Enter The Option");
			System.out.println("1 For Search Applications");
			System.out.println("2 Update The Status After Interview");
			System.out.println("3 For Logout");
			int forward = 0;
			int optionMAC = 0;
			dummy = scanner.next();
			switch (dummy) {
			case "1": {
				searchApplications();
				break;
			}
			case "2": {
				StatusUpdateingAfterInterview();
				break;
			}
			case "3": {
				System.err.println("You Are Logged Out");
				logger.info("MAC logged out");
				startTheProgram();
			}
			default: {
				System.err.println("Wrong Input");
				logger.info("MAC Choosen Incorrect Option");
				continue;
			}
			}
		} while (true);
	}

	// =====================STATUS AFTER INTERVIEW========
	private static void StatusUpdateingAfterInterview() throws ParseException,
			IOException {
		System.out.println("==============================");
		System.out.println("STATUS SECTION AFTER INTERVIEW");
		System.out.println("==============================");
		System.out.println();
		int id = 0;
		System.out
				.println("Enter Application Id To change The Status As Accepted/Rejected");
		try {
			id = scanner.nextInt();
		} catch (InputMismatchException e) {
			logger.error("Input Mismatch Happened");
			scanner.nextLine();
			System.err.println("Numeric value Only!!!");
		}
		while (true) {
			if (imacservice.isvalidApplicationId(id))
				break;
			else {
				System.err.println("Inavlid Application Id, Try Again");
				try {
					id = scanner.nextInt();

				} catch (InputMismatchException e) {
					scanner.nextLine();
					System.err.println("Numeric value Only!!!");
					logger.error("Input Mismatch Happened");
					System.out.println("Enter Application Id");
				}
			}
		}

		System.out.println("Enter Accepted or Rejected");
		String updateString = "";

		updateString = scanner.next();
		if (updateString.equals("Accepted") || updateString.equals("Rejected")) {

			String status = imacservice.macstatusupdate(id, updateString);

			if (status != null) {
				System.out.println("=======================");
				System.out.println(status);
				System.out.println("=======================");
				System.out.println();
				System.out.println();
				System.out.println("================");
				System.out.println("   THANK YOU    ");
				System.out.println("================");
			} else {
				System.err.println("=======================");

				System.err.println(status);
				System.err.println("=======================");
				System.out.println();
				System.out.println("================");
				System.out.println("   THANK YOU    ");
				System.out.println("================");
				System.out.println();

			}
		} else {
			System.err.println("Enter Only Accepted Or Rejected");

			StatusUpdateingAfterInterview();
		}
		loginAsMAC();
	}

	// =====================SEARCHING APPLICATION=========
	private static void searchApplications() throws ParseException, IOException {
		System.out.println("===============================");
		System.out.println("SEARCH SECTION FOR APPLICATIONS");
		System.out.println("===============================");
		System.out.println();
		System.out.println("1.View The Specific Applications");

		System.out.println("Please Choose One Code To See The Applications :");
		System.out.println("100 For C ");
		System.out.println("101 For Java");
		System.out.println("103 For Java");
		System.out.println("104 For Angular JS");
		System.out.println("105  For C++");
		System.out.println("");

		System.out.println("Choose Code:");
		int program = 0;

		try {
			program = scanner.nextInt();
		} catch (InputMismatchException e) {
			scanner.nextLine();
			// System.err.println("Invalid Input");
		}
		while (true) {
			if (imacservice.isValidProgramCode(program))
				break;
			else {
				System.err.println("Invalid Input");
				System.out.println("Choose Code:");
				try {
					program = scanner.nextInt();
				} catch (InputMismatchException e) {
					scanner.nextLine();
					System.err.println("Invalid Input");
				}
			}

		}
		specificprogram = imacservice.scheduledprogram(program);
		System.out.println();
		System.out.println("==========================================");
		System.out.println("List of Applicants For Specific Programs :");
		System.out.println("==========================================");
		System.out.println();
		for (ApplicantBean applicantbean : specificprogram) {
			System.out.println("ApplicantName: " + applicantbean.getUsername()
					+ " ||" + "ApplicantDob : " + applicantbean.getDob()
					+ "ApplicantMarks : " + applicantbean.getMarks()
					+ "ApplicantGoals: " + applicantbean.getGoals()
					+ "ApplicantHighestQualification : "
					+ applicantbean.getQualification()
					+ "ApplicantScheduledProgramId : "
					+ applicantbean.getScheduledprogramid() + "ApplicatId :"
					+ applicantbean.getApplicationid() + "||"
					+ "Applicant Status :" + applicantbean.getStatus() + "||  "
					+ "Applicant date Of Interview : "
					+ applicantbean.getDate_of_interview()
					+ "ApplicantEmainid :" + applicantbean.getEmailid());
			System.out.println();
		}

		loginAsMAC();
	}

	private static boolean maclogin(String macusername, String macpassword) {
		IMacService serviceMac = new MacServiceImp();
		return serviceMac.maclogin(macusername, macpassword);
	}

	private static boolean adminlogin(String adminusername, String adminpassword)
			throws UserException {
		IAdminService serviceImp = new AdminServiceImp();

		return serviceImp.adminlogin(adminusername, adminpassword);
	}

	public ArrayList<ApplicantBean> scheduledprogram(int program) {
		imacservice = new MacServiceImp();
		return imacservice.scheduledprogram(program);
	}

	// =================STUDENT APPLICATION FORM=======
	private static void getApplicationFromStudent(Scanner scanner)
			throws IOException {
		IApplicantService service;

		System.out.println("======================");
		System.out.println("  APPLICATION FORM   ");
		System.out.println("======================");
		// =========username validation==========
		System.out.println("Enter you name:");
		String applicantname = buffered.readLine();

		while (true) {
			if (applicantService.isValidApplicantname(applicantname))
				break;
			else {
				System.err
						.println("Ivalid Name, Name Should Be Greater Than 8 Characters");

				System.out.println("Enter Your Name:");
				try {
					applicantname = buffered.readLine();
				} catch (InputMismatchException e) {
					logger.error("Input Mismatch Happened");
					scanner.nextLine();
					System.err.println("Enter Characters only!!!");
					System.out.println("Enter Your Name:");
				}
			}
		}
		// =============Date of Birth Validation============
		System.out.println("Enter Date Of Birth (ddmmyyyy format):");
		long dob = 0;
		try {
			dob = scanner.nextLong();
		} catch (InputMismatchException e) {
			logger.error("Input Mismatch Happened");
			scanner.nextLine();
			System.err.println("Invalid DOB && Follow The Given Format");

		}

		while (true) {
			if (applicantService.isValidApplicantDob(dob))
				break;
			else {
				System.err.println("Invalid DOB && Follow The Given Format");

				System.out.println("Enter Date Of Birth:");
				try {
					dob = scanner.nextLong();
				} catch (InputMismatchException e) {
					logger.error("Input Mismatch Happened");
					scanner.nextLine();
					System.err
							.println("Invalid DOB && Follow The Given Format");
				}

			}
		}
		// ====================Qualification Validation==============
		String qualification = "";
		int flag = 0;
		System.out
				.println("Enter Highest Qualification (12 | Btech | Phd | bsc | Mtech | msc |others):");
		do {
			qualification = buffered.readLine();

			if (qualification.equalsIgnoreCase("12")
					|| qualification.equalsIgnoreCase("btech")
					|| qualification.equalsIgnoreCase("phd")
					|| qualification.equalsIgnoreCase("bsc")
					|| qualification.equalsIgnoreCase("mtech")
					|| qualification.equalsIgnoreCase("msc")
					|| qualification.equalsIgnoreCase("others")) {
				flag = 1;
				while (true) {
					if (applicantService
							.isValidApplicantQualification(qualification))
						break;
					else {
						System.err.println("Invalid Qualification, Try Again");

						System.out.println("Enter Highest Qualification:");
						try {
							qualification = buffered.readLine();
						} catch (InputMismatchException e) {
							logger.error("Input Mismatch Happened");
							scanner.nextLine();
							System.err.println("Enter Characters Only!!!");
						}
					}
				}
			} else {
				System.err
						.println("Enter  Only (12 | Btech | Phd | bsc | Mtech | msc |others):");
			}
		} while (flag != 1);

		// ==========Percentage Validations=================
		System.out.println("Enter Highest Qualification Percentage:");
		float marks = 0;
		try {
			marks = scanner.nextFloat();
		} catch (InputMismatchException e) {
			scanner.nextLine();
			System.err.println("Invalid Percentage, Try Again");
		}
		while (true) {
			if (marks < 100 && marks > 0)

				break;
			else {
				System.err.println("Invalid Percentage, Try Again");

				System.out.println("Enter Highest Qualification Percentage:");
				try {
					marks = scanner.nextFloat();
				} catch (InputMismatchException e) {
					logger.error("Input Mismatch Happened");
					scanner.nextLine();
					System.err.println("Invalid Percentage, Try Again");
				}
			}
		}
		// =========Validation of Goals===========
		System.out.println("Enter Goals:");
		String goals = "";
		boolean dummy = false;

		goals = buffered.readLine();

		logger.error("Input Mismatch Happened");
		// scanner.nextLine();
		// System.err.println("Invalid Goals,Try Again");
		// }
		while (!dummy) {
			if (applicantService.isValidApplicantGoals(goals)) {
				dummy = true;
			}

			else {
				System.err.println("Invalid Goals,Try Again");
				System.out.println("Enter Goals:");
				try {
					goals = buffered.readLine();
				} catch (InputMismatchException e) {
					logger.error("Input Mismatch Happened");
					scanner.nextLine();
					System.err.println("Invalid Goals,Try Again");
				}
			}
		}
		// =======Email Validation=========================
		System.out.println("Enter Your Email Id:");
		String applicantemail = "";
		try {
			applicantemail = scanner.next();
		} catch (InputMismatchException e) {
			logger.error("Input Mismatch Happened");
			scanner.nextLine();
			System.err.println("Invalid Email Id:");
		}
		while (true) {
			if (applicantService.isValidEmail(applicantemail))
				break;
			else {
				System.err.println("Enter Valid Email");
				System.out.println("Enter Email Id:");
				try {
					applicantemail = scanner.next();
				} catch (InputMismatchException e) {
					logger.error("Input Mismatch Happened");
					scanner.nextLine();
					System.err.println("Enter Valid Email Id?");
				}
			}

		}
		// =========Scheduled program Id validation==========
		System.out.println("Enter  Scheduled Program Id:");
		int programid = 0;
		try {
			programid = scanner.nextInt();
		} catch (InputMismatchException e) {
			logger.error("Input Mismatch Happened");
			scanner.nextLine();
			System.err
					.println("Invalid Input && Scheduled Program Id Should Be 3 digits && Greater Than 0 ");
		}
		while (true) {
			if (applicantService.isvalidScheduledProgramId(programid))
				break;
			else {
				System.err
						.println("Invalid Input && Scheduled Program Id Should Be 3 digits && Greater Than 0 ");
				System.out.println("Enter Scheduled Program Id:");
				try {
					programid = scanner.nextInt();
				} catch (InputMismatchException e) {
					logger.error("Input Mismatch Happened");
					scanner.nextLine();
					System.err
							.println("Invalid Input && Scheduled Program Id Should Be 3 digits && Greater Than 0 ");
				}

			}
		}

		ApplicantBean applicant = new ApplicantBean();

		applicant.setDob(dob);
		applicant.setEmailid(applicantemail);
		applicant.setGoals(goals);
		applicant.setMarks(marks);
		applicant.setQualification(qualification);
		applicant.setUsername(applicantname);

		applicant.setScheduledprogramid(programid);

		service = new ApplicantService();
		int status = service.addApplicantDetails(applicant);
		System.out.println("==========================");
		System.out.println("SUCCESSFULLY ADDED DEATILS");
		System.out.println("===========================");
		System.out.println();
		System.out.println("Details are added with id:" + status);
		System.out.println();
		System.out.println("================");
		System.out.println("   THANK YOU    ");
		System.out.println("================");
		// System.out.println("Status : Accepted On->");

	}

}
