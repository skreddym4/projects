package com.cg.uas.exception;

public class UserException extends Exception {
public UserException() {
	super();
}
}
