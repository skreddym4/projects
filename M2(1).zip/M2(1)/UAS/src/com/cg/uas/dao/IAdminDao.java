package com.cg.uas.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.uas.bean.AdminBean;
import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.ProgramsOffered;
import com.cg.uas.bean.ScheduledPrograms;
import com.cg.uas.exception.UserException;

public interface IAdminDao {

	boolean adminlogin(String adminusername, String adminpassword)
			throws UserException;

	int addnewprogram(ProgramsOffered programsoffered) throws UserException;

	int deleteprogram(String deleteprogram) throws UserException;

	int addnewprogramschedulesdetails(ScheduledPrograms scheduledPrograms)
			throws UserException;

	// int settingstatus(int applicationid );
	String deletescheduledprogram(int programcode) throws UserException;

	public ArrayList<ApplicantBean> listofAcceptedOrRejectedList(String string)
			throws UserException;
	public ArrayList<ApplicantBean> viewallprogramsbyadmin() throws SQLException, UserException;
	public boolean SetCutOffPercentage(int percentage) throws SQLException, UserException;
	public ArrayList<ProgramsOffered> listOfPrograms(); 

	

}
