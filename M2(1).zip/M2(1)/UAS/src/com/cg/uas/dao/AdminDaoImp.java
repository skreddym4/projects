package com.cg.uas.dao;

import java.sql.PreparedStatement;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.ProgramsOffered;
import com.cg.uas.bean.ScheduledPrograms;
import com.cg.uas.dbutil.DBUtil;
import com.cg.uas.exception.UserException;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class AdminDaoImp implements IAdminDao {
	static Connection conn = null;

	public boolean adminlogin(String adminusername, String adminpassword)
			throws UserException {
		try {
			conn = DBUtil.getConnection();
			PreparedStatement preparedStatement = conn
					.prepareStatement(IQueryMapper.RETRIEVE_QUERY_ADMIN);

			preparedStatement.setString(1, adminusername);

			preparedStatement.setString(2, adminpassword);

			ResultSet rSet = preparedStatement.executeQuery();
			boolean data = rSet.next();
			return data;

		} catch (SQLException e) {
			System.err.println("Error Occured At:" + e.getMessage());
			throw new UserException();

		}

	}

	@Override
	public int addnewprogramschedulesdetails(ScheduledPrograms scheduledPrograms)
			throws UserException {
		int status = 0;
		try {
			conn = DBUtil.getConnection();

			PreparedStatement preparedStatement = conn
					.prepareStatement(IQueryMapper.INSERT_INTO_PROGRAMS_TABLE);

			String name = scheduledPrograms.getProgram_name();

			preparedStatement.setLong(1,
					scheduledPrograms.getScheduled_program_id());

			preparedStatement.setString(2, name);

			preparedStatement.setString(3, scheduledPrograms.getLocation());

			preparedStatement.setDate(4, scheduledPrograms.getStart_date());

			preparedStatement.setDate(5, scheduledPrograms.getEnd_date());

			preparedStatement.setInt(6,
					scheduledPrograms.getSessions_per_week());

			int storedStatus = preparedStatement.executeUpdate();

			if (storedStatus == 1) {
				PreparedStatement preparedstatement = conn
						.prepareStatement(IQueryMapper.IDFORINSERTINGPROGRAMNEWSCHEDULED);
				ResultSet rs = preparedstatement.executeQuery();
				rs.next();
				status = rs.getInt(1);
			}
		}

		catch (Exception e) {
			System.err.println(e.getMessage());
		
		}

		return status;

	}

	@Override
	public int addnewprogram(ProgramsOffered programsoffered) {
		int status = 0;
		try {
			conn = DBUtil.getConnection();

			PreparedStatement preparedStatement = conn
					.prepareStatement(IQueryMapper.INSERT_INTO_PROGRAMS_STRING);

			String name = programsoffered.getProgramName();

			preparedStatement.setString(1, name);

			preparedStatement.setString(2,
					programsoffered.getProgramDescription());

			preparedStatement.setString(3,
					programsoffered.getApplicationEligibility());

			preparedStatement.setInt(4, programsoffered.getDuration());

			preparedStatement.setString(5,
					programsoffered.getDegreeCertificationOffered());

			int storedStatus = preparedStatement.executeUpdate();

			if (storedStatus == 1) {
				PreparedStatement preparedstatement = conn
						.prepareStatement(IQueryMapper.IDVALUE_FOR_INSERTINGNEWPROGRAM);
				ResultSet rs = preparedstatement.executeQuery();
				rs.next();
				status = rs.getInt(1);
			}
		}

		catch (Exception e) {
			System.out.println(e);
		}

		return status;

	}

	@Override
	public int deleteprogram(String programsOffered) {
		// String deletedprogram=programsOffered.getProgramName();
		boolean deletestatus = false;
		try {
			conn = DBUtil.getConnection();
			PreparedStatement preparedStatement = conn
					.prepareStatement(IQueryMapper.DELETE_PROGRAM);

			preparedStatement.setString(1, programsOffered);
			int statusofdeleteprogram = preparedStatement.executeUpdate();

			if (statusofdeleteprogram == 1) {
				System.out.println("=====================");
				System.out.println(" DELETED SUCCESSFULLY ");
				System.out.println("=====================");
			} else {
				System.err.println("==========================================");
				System.err.println("PLEASE ENTER OPTION AS MENTION IN THE LIST");
				System.err.println("==========================================");
				System.out.println();
				System.out.println("=================");
				System.out.println("   THANK YOU     ");
				System.out.println("=================");
				System.out.println();
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return 0;
	}


	@Override
	public String deletescheduledprogram(int programcode) {
		String statusafterdeleting = "";
		String message="";
		try {
			conn = DBUtil.getConnection();
			PreparedStatement preparedStatement = conn
					.prepareStatement(IQueryMapper.DELETE_SCHEDULED_PROGRAM);
			preparedStatement.setInt(1, programcode);
			int status = preparedStatement.executeUpdate();
			if (status == 1) {
               // System.err.println("==========================");
				//System.err.println("   DELETED SUCCESSFULLY  ");
				message="DELETED SUCCESSFULLY ";
				//System.err.println("==========================");
			} else {
				//System.err.println("===========================================");
				//System.err.println("   CHOOSEN ID WAS NOT PRESENT IN DATABASE  ");
				message="CHOOSEN ID WAS NOT PRESENT IN DATABASE ";
				//System.err.println("===========================================");
				
			}

		} catch (Exception e) {
			
			System.out.println(e);
		}
		return message;
	}

	@Override
	public ArrayList<ApplicantBean> listofAcceptedOrRejectedList(String string) {
		
		ArrayList<ApplicantBean> listaccepted = new ArrayList<>();
		int applicationid = 0;
		try {
			conn = DBUtil.getConnection();
			PreparedStatement preparedStatement = conn
					.prepareStatement(IQueryMapper.LIST_OF_ACCEPTED_OR_REJECTED);
			preparedStatement.setString(1, string);
			ResultSet resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				ApplicantBean applicantBean = new ApplicantBean();
				applicationid = resultSet.getInt("application_id");
				applicantBean.setApplicationid(applicationid);
				listaccepted.add(applicantBean);

			}	

		} catch (Exception e) {
			System.out.println(e);
		}
		return listaccepted;

	}

	@Override
	public ArrayList<ApplicantBean> viewallprogramsbyadmin()
			throws SQLException, UserException {
		ApplicantBean bean = null;
		ArrayList<ApplicantBean> listofallaplication = new ArrayList<>();

		conn = DBUtil.getConnection();

		PreparedStatement preparedStatement = conn
				.prepareStatement(IQueryMapper.VIEW_ALL_APPLICATIONS_BY_ADMIN);

		ResultSet resultSet = preparedStatement.executeQuery();
		if(resultSet !=null){
		while (resultSet.next()) {

			bean=new ApplicantBean();
			
			int applicantid = resultSet.getInt("application_id");
			String applicantname = resultSet.getString("full_name");

			long applicantdob = resultSet.getLong("date_of_birth");
			String highestqualification = resultSet
					.getString("highest_qualification");
			float marks = resultSet.getFloat("marks_obtained");

			String goalsString = resultSet.getString("goals");
			String EmailidString = resultSet.getString("email_id");
			int Id = resultSet.getInt("scheduled_program_id");

			// long DateOfInterview=resultSet.getLong("date_of_interview");
			String statusString = resultSet.getString("status");
        
			bean.setApplicationid(applicantid);

			bean.setUsername(applicantname);
			bean.setDob(applicantdob);
			bean.setQualification(highestqualification);
			bean.setMarks(marks);
			bean.setGoals(goalsString);
			bean.setEmailid(EmailidString);
			bean.setScheduledprogramid(Id);
			// bean.setDate_of_interview(DateOfInterview);
			bean.setStatus(statusString);
			listofallaplication.add(bean);
		}
		}else {
		return null;
		}

		return listofallaplication;
	}

	@Override
	public boolean SetCutOffPercentage(int percentage) throws SQLException,
			UserException {
		boolean set = false;
		
		//System.out.println(percentage);
		
		int status = 0;
		int status1 = 0;
	
		int status2 = 0;

		try {
			conn = DBUtil.getConnection();
			PreparedStatement preparedStatement = conn
					.prepareStatement(IQueryMapper.UPDATE_STATUS_COLUMN1);

			preparedStatement.setInt(1, percentage);

			status1 = preparedStatement.executeUpdate();
			
			//System.out.println("status 1:"+status1);

			PreparedStatement preparedStatement1 = conn
					.prepareStatement(IQueryMapper.UPDATE_STATUS_COLUMN2);
			preparedStatement1.setInt(1, percentage);
			
			status2 = preparedStatement1.executeUpdate();
			
			//System.out.println("status 2:"+status2);
		} catch (Exception e) {
			System.err.println(e);
		}

		return true;
	}

	@Override
	public ArrayList<ProgramsOffered> listOfPrograms() {
		ArrayList<ProgramsOffered> list=new ArrayList<>();
		ProgramsOffered programsOffered=new ProgramsOffered();
		String  nameOfProgramString=null;
		try {
			conn = DBUtil.getConnection();
			PreparedStatement preparedStatement = conn
					.prepareStatement(IQueryMapper.LIST_OF_PROGRAMS);
			 ResultSet set=preparedStatement.executeQuery();
			if(set !=null){
				 System.out.println("========================================");
				 System.out.println("\tLIST OF PROGRAM NAMES");
				 System.out.println("========================================");	
			 while(set.next()){
				 
				 System.out.println("Applications Name Are : "+set.getString(1));
			 }
			}else{
				System.err.println("========================================");
				System.err.println("       NO PROGRAMS ARE AVAILABLE        ");
				System.err.println("========================================");
			}	
	}catch(Exception e){
		System.err.println(e);
	}
		return list;

	
}}
