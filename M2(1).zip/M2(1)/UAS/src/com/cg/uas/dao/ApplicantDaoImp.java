package com.cg.uas.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

//import com.capgg.ems.bean.Employee;
import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.ProgramsOffered;
import com.cg.uas.bean.ScheduledPrograms;
import com.cg.uas.dbutil.DBUtil;

public class ApplicantDaoImp implements IApplicantDao {
	private Connection conn = null;

	ProgramsOffered programObject = new ProgramsOffered();

	public int addApplicantDetails(ApplicantBean applicant) {

		int status = 0;
		try {
			conn = DBUtil.getConnection();

			PreparedStatement preparedStatement = conn
					.prepareStatement(IQueryMapper.INSERT_QUERY);

			String name = applicant.getUsername();
			preparedStatement.setString(1, name);
			preparedStatement.setLong(2, applicant.getDob());
			preparedStatement.setString(3, applicant.getQualification());
			preparedStatement.setFloat(4, applicant.getMarks());
			preparedStatement.setString(5, applicant.getEmailid());
			preparedStatement.setString(6, applicant.getGoals());

			preparedStatement.setInt(7, applicant.getScheduledprogramid());

			int storedStatus = preparedStatement.executeUpdate();

			if (storedStatus == 1) {
				PreparedStatement preparedstatement = conn
						.prepareStatement(IQueryMapper.IDVALUE);
				ResultSet rs = preparedstatement.executeQuery();
				rs.next();
				status = rs.getInt(1);
			}
		}

		catch (Exception e) {
			System.out.println(e);
		}

		return status;

	}

	@Override
	public void displayall() {

		Connection conn = null;
		try {
			conn = DBUtil.getConnection();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.programs);

			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {

				ProgramsOffered programObject = new ProgramsOffered();

				String programName = rs.getString("PROGRAM");
				// System.out.println("TEST " + programName);

				String programDescription = rs.getString("DESCRIPTION");
				// System.out.println("TEST " + programName);

				String ae = rs.getString("APPLICANT_ELIGIBILITY");
				// System.out.println("TEST " + ae);
				int duration = rs.getInt("DURATION");

				String degreeCertificationOffered = rs
						.getString("DEGREE_CERTIFICATE_OFFERED");

				programObject.setApplicationEligibility(ae);
				programObject.setDuration(duration);
				programObject.setProgramName(programName);
				programObject.setProgramDescription(programDescription);
				programObject
						.setDegreeCertificationOffered(degreeCertificationOffered);
				ArrayList<ProgramsOffered> listOfProgramsOffered = new ArrayList();

				listOfProgramsOffered.add(programObject);

				for (ProgramsOffered programs : listOfProgramsOffered) {
					System.out.println(programs.getProgramName() + " || "
							+ programs.getApplicationEligibility() + " || "
							+ programs.getProgramDescription() + " || "
							+ programs.getDuration() + "|| "
							+ programs.getDegreeCertificationOffered());
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void displayprogramsschedule() {
		ScheduledPrograms scheduledprograms = new ScheduledPrograms();
		Connection conn = null;
		try {
			conn = DBUtil.getConnection();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.RETRIEVE_ALL_PROGRAMS);

			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {

				ProgramsOffered programObject = new ProgramsOffered();
				int scheduledprogramid = rs.getInt("SCHEDULED_PROGRAM_ID");

				String programName = rs.getString("PROGRAM_NAME");
				// System.out.println("TEST " + programName);

				String LOCATION = rs.getString("LOCATION");
				// System.out.println("TEST " + programName);

				Date start_date = rs.getDate("START_DATE");
				// System.out.println("TEST " + ae);
				Date end_date = rs.getDate("END_DATE");

				int session_per_week = rs.getInt("SESSIONS_PER_WEEK");

				scheduledprograms.setEnd_date((java.sql.Date) end_date);
				scheduledprograms.setProgram_name(programName);
				scheduledprograms.setStart_date((java.sql.Date) start_date);
				scheduledprograms.setScheduled_program_id(scheduledprogramid);
				scheduledprograms.setSessions_per_week(session_per_week);
				scheduledprograms.setLocation(LOCATION);
				ArrayList<ScheduledPrograms> listOfScheduledPrograms = new ArrayList();

				listOfScheduledPrograms.add(scheduledprograms);

				for (ScheduledPrograms programs : listOfScheduledPrograms) {
					System.out.println(programs.getScheduled_program_id()
							+ " || " + programs.getProgram_name() + " || "
							+ programs.getStart_date() + " || "
							+ programs.getEnd_date() + " || "
							+ programs.getSessions_per_week() + " || "
							+ programs.getLocation());
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public String applicationstatus(int applicationid) {
		String statusofapplication ="";
		 String dateofinterview="";
		try {
			conn = DBUtil.getConnection();
			PreparedStatement preparedStatement = conn
					.prepareStatement(IQueryMapper.RETRIEVE_STATUS_DATE_OF_INTERVIEW);
			preparedStatement.setInt(1, applicationid);
			ResultSet set = preparedStatement.executeQuery();
			
			
			if(!set.isBeforeFirst()){
				return null;
			}
			
			set.next();
			
			//if(!set==null) {
			if(set.getString("status").equalsIgnoreCase("Accepted")){
				statusofapplication=set.getString("status");
				dateofinterview=set.getString("DATE_OF_INTERVIEW");
			}
			else{
				statusofapplication=set.getString("status");
				dateofinterview="No Date Of interview";
			}
			
		} catch (Exception e) {
			System.out.println(e);
		}
		String statusString=statusofapplication+","+dateofinterview;
		return statusString;
	}

	@Override
	public String StatusAfterinterview(int applicationid) {
		String statusAfterInterview=null;
		Connection conn = null;
		try {
			conn = DBUtil.getConnection();

			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.SELECT_STATUS_AFTER_INTERVIEW);
			pstmt.setInt(1, applicationid);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()){
		    statusAfterInterview = rs.getString("status");
			}else{
				System.out.println();
				System.err.println("================================");
				System.err.println("     INVALID APPLICATION ID     ");
				System.err.println("================================");
				System.out.println();
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		//System.out.println(statusAfterInterview);
		return statusAfterInterview;

	}

	
}
