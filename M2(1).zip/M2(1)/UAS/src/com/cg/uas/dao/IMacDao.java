package com.cg.uas.dao;

import java.util.ArrayList;

import com.cg.uas.bean.ApplicantBean;

public interface IMacDao {
	public boolean maclogin(String macusername,String macpassword);
	//public int displayprograms(String progrmas);
	public ArrayList<ApplicantBean> scheduledprograms(int program);
	public String macstatusupdate(int applicationid,String statusafterinterview);
	
}
