package com.capgemini.laps.service;



import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.laps.bean.CustomerDetailsBean;
import com.capgemini.laps.bean.LoanApplicationBean;
import com.capgemini.laps.dao.CustomerDAO;
import com.capgemini.laps.dao.ICustomerDAO;
import com.capgemini.laps.exception.LoanException;

public class CustomerService implements ICustomerService {

	ICustomerDAO customerDAO=null;
	
	
	public CustomerService() {
	     customerDAO = new CustomerDAO();
	}

	@Override
	public int addApplicationDetails(LoanApplicationBean loanApplicationBean) throws LoanException{

		return customerDAO.addApplicationDetails(loanApplicationBean);
	}

	@Override
	public boolean addCustomerDetails(CustomerDetailsBean customerBean) throws LoanException{

		return customerDAO.addCustomerDetails(customerBean);
	}

	@Override
	public String getApplicationStatus(int appId) throws LoanException {

		return customerDAO.getApplicationStatus(appId);
	}

	

	
	
	
	
	

	@Override
	public boolean isValidEmailId(String emailId) {
		Pattern namePattern=Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+.[A-Za-z]{2,20}$");
		Matcher nameMatcher=namePattern.matcher(emailId);
		return nameMatcher.matches();
	}

	@Override
	public boolean isValidCountOfDependents(int countOfDependents) {
		return (countOfDependents > 0 && countOfDependents <=10);
	}

	@Override
	public boolean isValidMobileNumber(long mobileNumber, long phoneNumber) {

		String mNumber = Long.toString(mobileNumber);
		
		Pattern namePattern=Pattern.compile("^[7-9][0-9]{9}");
		Matcher nameMatcher=namePattern.matcher(mNumber);
		boolean m= nameMatcher.matches();
		if(phoneNumber == mobileNumber){
			System.err.println("Mobile Number Should Be Different From Phone Number...!!");
			return false;
		}
		else
			return m;
	}

	@Override
	public boolean isValidPhoneNumber(long phoneNumber) {
        String pNumber = Long.toString(phoneNumber);
		
		Pattern namePattern=Pattern.compile("^[7-9][0-9]{9}");
		Matcher nameMatcher=namePattern.matcher(pNumber);
		return nameMatcher.matches();
	}

	@Override
	public boolean isValidMaritalStatus(String maritalStatus) {
		return ("Married".equals(maritalStatus) || "Unmarried".equals(maritalStatus) );
	}
    
	@Override
	public boolean isValidDateOfBirth(String dateOfBirth) {
		Pattern namePattern=Pattern.compile("(0?[1-9]|[12][0-9]|3[01])/(0?[1-9]|1[012])/((19|20)\\d\\d)");
		Matcher nameMatcher=namePattern.matcher(dateOfBirth);
		return nameMatcher.matches();
		
	}
    @Override
	public boolean isValidApplicantName(String applicantName) {
		Pattern namePattern=Pattern.compile("[A-Za-z ]{3,20}$");
		Matcher nameMatcher=namePattern.matcher(applicantName);
		return nameMatcher.matches();
	}

	@Override
	public boolean isValidApplicationId(int appId) {
		return (appId >0 && appId <= 100000);
	}


	@Override
	public boolean isValidLoanProgram(String loanProgram) {

		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,10}$");
		Matcher nameMatcher=namePattern.matcher(loanProgram);
		return nameMatcher.matches();
	}

	@Override
	public boolean isValidAmountOfLoan(long amountOfLoan) {

		return (amountOfLoan>0 && amountOfLoan <= 5000000);
	}

	@Override
	public boolean isValidAddressOfProperty(String addressOfProperty) {

		return (addressOfProperty.length() > 2 && addressOfProperty.length() <=20);
	}

	@Override
	public boolean isValidAnnualFamilyIncome(long annualFamilyIncome) {

		return (annualFamilyIncome>0 && annualFamilyIncome <= 10000000);
	}

	@Override
	public boolean isValidDocumentProofsAvailable(String documentProofsAvailable) {

		return ("Aadhar".equals(documentProofsAvailable) || "PanCard".equals(documentProofsAvailable) || "VoterId".equals(documentProofsAvailable));
	}

	@Override
	public boolean isValidGuaranteeCover(String guaranteeCover) {

		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,20}$");
		Matcher nameMatcher=namePattern.matcher(guaranteeCover);
		return nameMatcher.matches();
	}

	@Override
	public boolean isValidMarketValueOfGuaranteeCover(int marketValueOfGuaranteeCover) {

		return (marketValueOfGuaranteeCover>0 && marketValueOfGuaranteeCover <= 50000000);
	}

	
}
