package com.capgemini.laps.service;

import java.util.List;

import com.capgemini.laps.bean.ApprovedLoansBean;
import com.capgemini.laps.bean.LoanApplicationBean;
import com.capgemini.laps.bean.LoanProgramsBean;
import com.capgemini.laps.exception.LoanException;

public interface IAdminService {

	

	public abstract boolean addLoanPrograms(LoanProgramsBean loanProgramsBean) throws LoanException;

	public abstract boolean deleteLoanProgram(String programName) throws LoanException;

	public abstract List<LoanApplicationBean> viewApplications(String applicationStatus) throws LoanException;

	

	public abstract boolean isValidProgramName(String programName);

	public abstract boolean isValidDescription(String description);

	public abstract boolean isValidType(String type);

	public abstract boolean isValidDurationInYears(int durationInYears);

	public abstract boolean isValidMinLoanAmount(long minLoanAmount);

	public abstract boolean isValidMaxLoanAmount(long maxLoanAmount,long minLoanAmount);

	public abstract boolean isValidRateOfInterest(float rateOfInterest);

	public abstract boolean isValidProofsRequired(String proofsRequired);

	public abstract boolean isValidApplicationStatus(String applicationStatus);

	public abstract List<ApprovedLoansBean> displayAllApprovedLoans() throws LoanException;

	public abstract boolean isValidReply(String reply);
}
