package com.capgemini.laps.service;

import java.util.List;

import com.capgemini.laps.bean.ApprovedLoansBean;
import com.capgemini.laps.bean.LoanApplicationBean;
import com.capgemini.laps.exception.LoanException;

public interface ILADService {

	

	public abstract List<LoanApplicationBean> viewApplications(String loanProgram) throws LoanException;

	public abstract boolean isValidApplicationId(int appId);

	public abstract String modifyApplicationStatus(int appId, String status) throws LoanException;

	public abstract boolean isValidApplicationStatus(String status,String currentStatus);

	public abstract String getCurrentStatus(int appId);

	public abstract String getCustomerName(int appId);

	public abstract long getAmountOfLoanGranted(int appId);

	public abstract int getYearsTimePeriod(int appId);

	public abstract float getRateOfInterest(int appId);

	public abstract boolean addApprovedLoansDetails(ApprovedLoansBean approvedLoansBean);

	public abstract boolean isValidReply(String reply);
}
