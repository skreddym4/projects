package com.capgemini.laps.service;

import java.util.List;


import com.capgemini.laps.bean.LoanProgramsBean;
import com.capgemini.laps.exception.LoanException;



public interface ILoanProgramsService {
	
	public abstract List<LoanProgramsBean> displayAll() throws LoanException;

	public abstract String login(String logid, String pwd) throws LoanException;

	

	

	
}
