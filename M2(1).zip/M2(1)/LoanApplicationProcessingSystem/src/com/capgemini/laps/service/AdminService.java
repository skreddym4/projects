package com.capgemini.laps.service;


import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.laps.bean.ApprovedLoansBean;
import com.capgemini.laps.bean.LoanApplicationBean;
import com.capgemini.laps.bean.LoanProgramsBean;
import com.capgemini.laps.dao.AdminDAO;
import com.capgemini.laps.dao.IAdminDAO;
import com.capgemini.laps.exception.LoanException;



public class AdminService implements IAdminService {

	
	IAdminDAO adminDAO = null;
	
	public AdminService() {

		adminDAO = new AdminDAO();
	}

	
	@Override
	public boolean addLoanPrograms(LoanProgramsBean loanProgramsBean) throws LoanException {
		return adminDAO.addLoanPrograms(loanProgramsBean);
		
	}

	@Override
	public boolean deleteLoanProgram(String programName) throws LoanException {
		return adminDAO.deleteLoanProgram(programName);
	}

	@Override
	public List<LoanApplicationBean> viewApplications(String applicationStatus) throws LoanException {

		List<LoanApplicationBean> loanApplicationList = adminDAO.viewApplications(applicationStatus);
		
		
		return loanApplicationList;
	}


	
	
	

	


	

	


	@Override
	public boolean isValidProgramName(String programName) {

		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,10}$");
		Matcher nameMatcher=namePattern.matcher(programName);
		return nameMatcher.matches();
	}


	@Override
	public boolean isValidDescription(String description) {

		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,20}$");
		Matcher nameMatcher=namePattern.matcher(description);
		return nameMatcher.matches();
	}


	@Override
	public boolean isValidType(String type) {

		return ("Purchase".equals(type) || "Construction".equals(type)|| "Extension".equals(type) || "Renovation".equals(type));
	}


	@Override
	public boolean isValidDurationInYears(int durationInYears) {

		return (durationInYears >0 && durationInYears <= 10);
	}


	@Override
	public boolean isValidMinLoanAmount(long minLoanAmount) {

		return (minLoanAmount >0 && minLoanAmount <=200000);
	}


	@Override
	public boolean isValidMaxLoanAmount(long maxLoanAmount, long minLoanAmount) {

		return (maxLoanAmount > minLoanAmount && maxLoanAmount <= 5000000);
	}


	@Override
	public boolean isValidRateOfInterest(float rateOfInterest) {

		return (rateOfInterest > 0 && rateOfInterest <=10);
	}


	@Override
	public boolean isValidProofsRequired(String proofsRequired) {

		return ("Aadhar".equals(proofsRequired) || "PanCard".equals(proofsRequired) || "VoterId".equals(proofsRequired));
	}


	@Override
	public boolean isValidApplicationStatus(String applicationStatus) {
		return ("Applied".equals(applicationStatus) || "Accepted".equals(applicationStatus) || "Rejected".equals(applicationStatus) || "Approved".equals(applicationStatus));
	}


	@Override
	public List<ApprovedLoansBean> displayAllApprovedLoans()throws LoanException {
		return adminDAO.displayAllApprovedLoans();
	}


	@Override
	public boolean isValidReply(String reply) {
		return ("YES".equals(reply.toUpperCase()) || "NO".equals(reply.toUpperCase()));
	}

   
	
	

	

}
