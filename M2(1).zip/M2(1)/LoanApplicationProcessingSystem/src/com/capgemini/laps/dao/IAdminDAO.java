package com.capgemini.laps.dao;

import java.util.List;

import com.capgemini.laps.bean.ApprovedLoansBean;
import com.capgemini.laps.bean.LoanApplicationBean;
import com.capgemini.laps.bean.LoanProgramsBean;
import com.capgemini.laps.exception.LoanException;

public interface IAdminDAO {

	

	public abstract boolean addLoanPrograms(LoanProgramsBean loanProgramsBean) throws LoanException;

	public abstract boolean deleteLoanProgram(String programName) throws LoanException;

	public abstract List<LoanApplicationBean> viewApplications(String applicationStatus) throws LoanException;

	public abstract List<ApprovedLoansBean> displayAllApprovedLoans() throws LoanException;

}
