package com.capgemini.laps.dao;

import com.capgemini.laps.bean.CustomerDetailsBean;
import com.capgemini.laps.bean.LoanApplicationBean;
import com.capgemini.laps.exception.LoanException;

public interface ICustomerDAO {

	public abstract int addApplicationDetails(LoanApplicationBean loanApplicationBean)throws LoanException;

	public abstract boolean addCustomerDetails(CustomerDetailsBean customerBean)throws LoanException;

	public abstract String getApplicationStatus(int appId) throws LoanException;

}
