package com.capgemini.laps.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.capgemini.laps.bean.ApprovedLoansBean;
import com.capgemini.laps.bean.LoanApplicationBean;
import com.capgemini.laps.bean.LoanProgramsBean;
import com.capgemini.laps.dbutil.DBConnection;
import com.capgemini.laps.exception.LoanException;

public class AdminDAO implements IAdminDAO {

	Connection con=null;
	PreparedStatement ps=null;
	ResultSet resultset = null;
	
	
	//------------------------ 1. Loan Application Processing System --------------------------
			/*******************************************************************************************************
			 - Function Name	:	addLoanPrograms(LoanProgramsBean loanProgramsBean)
			 - Input Parameters	:	LoanProgramsBean loanProgramsBean
			 - Return Type		:	boolean
			 - Throws			:  	LoanException
			 - Author			:	Shalu Kumari
			 - Creation Date	:	27/08/2018
			 - Description		:	Adding Loan Programs.
			 ********************************************************************************************************/
	
	
	@Override
	public boolean addLoanPrograms(LoanProgramsBean loanProgramsBean) throws LoanException{

		 int queryResult = 0;
		try {
			con = DBConnection.establishConnection();
			ps = con.prepareStatement(IQueryMapper.INSERT_QUERY_LOAN_PROGRAMS);
			
			ps.setString(1, loanProgramsBean.getProgramName());
			ps.setString(2, loanProgramsBean.getDescription());
			ps.setString(3, loanProgramsBean.getType());
			ps.setInt(4, loanProgramsBean.getDurationInYears());
			ps.setLong(5, loanProgramsBean.getMinLoanAmount());
			ps.setLong(6, loanProgramsBean.getMaxLoanAmount());
			ps.setFloat(7, loanProgramsBean.getRateOfInterest());
			ps.setString(8, loanProgramsBean.getProofsRequired());
			
			queryResult = ps.executeUpdate();
			
			if(queryResult ==0)
				return false;
			else
				return true;
			
		} catch (SQLException sqlException) {

			System.err.println("Either The Loan Program Having This Name Already Exists...Or The Connection Has Been Lost !! Please Check.. !!");
			throw new LoanException("Exception: "+sqlException.getMessage());
		}
		
	}


	//------------------------ 1. Loan Application Processing System --------------------------
			/*******************************************************************************************************
			 - Function Name	:	deleteLoanProgram(String programName)
			 - Input Parameters	:	String programName
			 - Return Type		:	boolean
			 - Throws			:  	LoanException
			 - Author			:	Shalu Kumari
			 - Creation Date	:	27/08/2018
			 - Description		:	Deleting the Loan Program. 
			 ********************************************************************************************************/
	
	
	@Override
	public boolean deleteLoanProgram(String programName) throws LoanException{

		 int queryResult = 0;
		try {
			con = DBConnection.establishConnection();
			ps = con.prepareStatement(IQueryMapper.DELETE_LOAN_PROGRAM_QUERY);
			ps.setString(1, programName);
			
			queryResult = ps.executeUpdate();
			
			if(queryResult ==0)
				return false;
			else
				return true;
		} catch (SQLException sqlException) {
   
			System.err.println("Customer Having This Loan Program Exists...Or The Connection Has Been Lost !! Please Check.... !!");
			throw new LoanException("Exception: "+sqlException.getMessage());
		}
		
		
	}


	//------------------------ 1. Loan Application Processing System --------------------------
			/*******************************************************************************************************
			 - Function Name	:	viewApplications(String applicationStatus)
			 - Input Parameters	:	String applicationStatus
			 - Return Type		:	List<LoanApplicationBean>
			 - Throws			:  	LoanException
			 - Author			:	Shalu Kumari
			 - Creation Date	:	27/08/2018
			 - Description		:	Viewing all Loan Applications on the Basis Of Application Status.
			 ********************************************************************************************************/
	
	
	@Override
	public List<LoanApplicationBean> viewApplications(String applicationStatus) throws LoanException{

		int loanApplicationCount = 0;
		try {
			con = DBConnection.establishConnection();
			List<LoanApplicationBean> loanApplicationList = new ArrayList<LoanApplicationBean>();
			ps = con.prepareStatement(IQueryMapper.VIEW_LOAN_APPLICATION_QUERY);
			ps.setString(1, applicationStatus);
			resultset = ps.executeQuery();
			
			while(resultset.next()){
				LoanApplicationBean loanApplicationBean = new LoanApplicationBean();
				loanApplicationBean.setApplicationId(resultset.getInt(1));
				loanApplicationBean.setApplicationDate(resultset.getDate(2));
				loanApplicationBean.setLoanProgram(resultset.getString(3));
				loanApplicationBean.setAmountOfLoan(resultset.getLong(4));
				loanApplicationBean.setAddressOfProperty(resultset.getString(5));
				loanApplicationBean.setAnnualFamilyIncome(resultset.getLong(6));
				loanApplicationBean.setDocumentProofsAvailable(resultset.getString(7));
				loanApplicationBean.setGuaranteeCover(resultset.getString(8));
				loanApplicationBean.setMarketValueOfGuaranteeCover(resultset.getInt(9));
				loanApplicationBean.setStatus(resultset.getString(10));
				loanApplicationBean.setDateOfInterview(resultset.getDate(11));
				
				loanApplicationList.add(loanApplicationBean);
				loanApplicationCount++;
				
			}
			
			if(loanApplicationCount == 0){
				return null;
			}else
				return loanApplicationList;
		} catch (SQLException sqlException) {

			System.err.println("Error Occured ....!!! ");
			throw new LoanException("Exception: "+sqlException.getMessage());
		}
		
		
	}


	//------------------------ 1. Loan Application Processing System --------------------------
	/*******************************************************************************************************
	 - Function Name	:	displayAllApprovedLoans()
	 - Input Parameters	:	No Input Parameter
	 - Return Type		:	List<ApprovedLoansBean>
	 - Throws			:  	LoanException
	 - Author			:	Shalu Kumari
	 - Creation Date	:	27/08/2018
	 - Description		:	Displaying All Approved Loans.
	 ********************************************************************************************************/
	
	
			@Override
			public List<ApprovedLoansBean> displayAllApprovedLoans()throws LoanException {
				int approvedLoansCount = 0;
				try {
					con = DBConnection.establishConnection();
					
					List<ApprovedLoansBean> approvedLoansList=new LinkedList<ApprovedLoansBean>();
					
					ps = con.prepareStatement(IQueryMapper.RETRIVE_ALL_APPROVED_LOANS);
					resultset=ps.executeQuery();
					
					while(resultset.next())
					{	
						ApprovedLoansBean approvedLoansBean=new ApprovedLoansBean();
						approvedLoansBean.setCustomerName(resultset.getString(1));
						approvedLoansBean.setAmountOfLoanGranted(resultset.getLong(2));
						approvedLoansBean.setMonthlyInstallment(resultset.getDouble(3));
						approvedLoansBean.setYearsTimePeriod(resultset.getInt(4));
						approvedLoansBean.setDownpayment(resultset.getDouble(5));
						approvedLoansBean.setRateOfInterest(resultset.getFloat(6));
						approvedLoansBean.setTotalAmountPayable(resultset.getDouble(7));
						approvedLoansList.add(approvedLoansBean);
						
						approvedLoansCount++;
					}			
					
					if( approvedLoansCount == 0)
						return null;
					else
						return approvedLoansList;
				} catch (SQLException sqlException) {
 
					throw new LoanException("Exception: "+sqlException.getMessage());
				}
				
			}


}
