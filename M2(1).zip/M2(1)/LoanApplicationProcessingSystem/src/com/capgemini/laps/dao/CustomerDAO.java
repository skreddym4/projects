package com.capgemini.laps.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.laps.bean.CustomerDetailsBean;
import com.capgemini.laps.bean.LoanApplicationBean;
import com.capgemini.laps.dbutil.DBConnection;
import com.capgemini.laps.exception.LoanException;

public class CustomerDAO implements ICustomerDAO {

	
	Connection con=null;
	PreparedStatement ps=null;
	ResultSet resultset = null;
	
	
	//------------------------ 1. Loan Application Processing System --------------------------
		/*******************************************************************************************************
		 - Function Name	:	addApplicationDetails(LoanApplicationBean loanApplicationBean)
		 - Input Parameters	:	LoanApplicationBean loanApplicationBean
		 - Return Type		:	int
		 - Throws			:  	LoanException
		 - Author			:	Shalu Kumari
		 - Creation Date	:	27/08/2018
		 - Description		:	Adding Loan Application
		 ********************************************************************************************************/


	@Override
	public int addApplicationDetails(LoanApplicationBean loanApplicationBean)throws LoanException {

		int applicationId=0;
		int queryResult=0;
		try {
			con=DBConnection.establishConnection();
			ps= con.prepareStatement(IQueryMapper.INSERT_QUERY_LOAN_APPLICATION);
			
			ps.setString(1, loanApplicationBean.getLoanProgram());
			ps.setLong(2,loanApplicationBean.getAmountOfLoan());
			ps.setString(3, loanApplicationBean.getAddressOfProperty());
			ps.setLong(4, loanApplicationBean.getAnnualFamilyIncome());
			ps.setString(5, loanApplicationBean.getDocumentProofsAvailable());
			ps.setString(6, loanApplicationBean.getGuaranteeCover());
			ps.setInt(7, loanApplicationBean.getMarketValueOfGuaranteeCover());
			
			queryResult= ps.executeUpdate();
			
			ps=con.prepareStatement(IQueryMapper.APPLICATION_ID_QUERY_SEQUENCE);
			resultset=ps.executeQuery();
			
			if(resultset.next()){
				applicationId=resultset.getInt(1);
			}
			
			if(queryResult==0){
				System.out.println("Insertion of data failed :: Please Try Again.");
			}else{
				return applicationId;
			}
			
		} catch (SQLException sqlException) {

			throw new LoanException("Exception: "+sqlException.getMessage());
		}
		
		return 0;
	}
	
	//------------------------ 1. Loan Application Processing System --------------------------
			/*******************************************************************************************************
			 - Function Name	:	addCustomerDetails(CustomerDetailsBean customerBean)
			 - Input Parameters	:	CustomerDetailsBean customerBean
			 - Return Type		:	boolean
			 - Throws			:  	LoanException
			 - Author			:	Shalu Kumari
			 - Creation Date	:	27/08/2018
			 - Description		:	Adding Customer Details
			 ********************************************************************************************************/

	@Override
	public boolean addCustomerDetails(CustomerDetailsBean customerBean) throws LoanException{


		int queryResult=0;
		try {
			con=DBConnection.establishConnection();
			ps= con.prepareStatement(IQueryMapper.INSERT_QUERY_CUSTOMER_DETAILS);
			
			ps.setInt(1, customerBean.getApplicationId());
			ps.setString(2, customerBean.getApplicantName());
			ps.setString(3, customerBean.getDateOfBirth());
			ps.setString(4, customerBean.getMaritalStatus());
			ps.setLong(5, customerBean.getPhoneNumber());
			ps.setLong(6, customerBean.getMobileNumber());
			ps.setInt(7, customerBean.getCountOfDependents());
			ps.setString(8, customerBean.getEmailId());
			
			queryResult=ps.executeUpdate();
			
			if(queryResult==0){
				return false;
			}else{
				return true;
			}
		} catch (SQLException sqlException) {
			throw new LoanException("Exception: "+sqlException.getMessage());
		}
		
	}

	//------------------------ 1. Loan Application Processing System --------------------------
	/*******************************************************************************************************
	 - Function Name	:	getApplicationStatus(int appId)
	 - Input Parameters	:	int appId
	 - Return Type		:	String
	 - Throws			:  	LoanException
	 - Author			:	Shalu Kumari
	 - Creation Date	:	27/08/2018
	 - Description		:	Getting Application Status On The Basis Of Application Id.
	 ********************************************************************************************************/

	
	@Override
	public String getApplicationStatus(int appId) throws LoanException{

		try {
			con = DBConnection.establishConnection();
			ps= con.prepareStatement(IQueryMapper.GET_APPLICATION_STATUS);
			
			ps.setInt(1, appId);
			resultset = ps.executeQuery();
			
			if(resultset.next()){
				String applicationStatus = resultset.getString(1);
				return applicationStatus;
			}else{
				System.out.println("Invalid Application Id Entered .");
				return null;
			}
		} catch (SQLException sqlException) {

			System.err.println("Error Occured At Getting Application Status... !!");
			throw new LoanException("Exception: "+sqlException.getMessage());
		}
		
	}

}
