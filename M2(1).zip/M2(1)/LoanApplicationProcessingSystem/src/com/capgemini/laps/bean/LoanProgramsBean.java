package com.capgemini.laps.bean;

public class LoanProgramsBean {

	
	private String programName;
	private String description;
	private String type;
	private int durationInYears;
	private long minLoanAmount;
	private long maxLoanAmount;
	private float rateOfInterest;
	private String proofsRequired;
	
	
	public LoanProgramsBean(String programName, String description,
			String type, int durationInYears, long minLoanAmount,
			long maxLoanAmount, float rateOfInterest, String proofsRequired) {
		super();
		this.programName = programName;
		this.description = description;
		this.type = type;
		this.durationInYears = durationInYears;
		this.minLoanAmount = minLoanAmount;
		this.maxLoanAmount = maxLoanAmount;
		this.rateOfInterest = rateOfInterest;
		this.proofsRequired = proofsRequired;
	}


	public LoanProgramsBean() {
		super();
	}


	public String getProgramName() {
		return programName;
	}


	public void setProgramName(String programName) {
		this.programName = programName;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public int getDurationInYears() {
		return durationInYears;
	}


	public void setDurationInYears(int durationInYears) {
		this.durationInYears = durationInYears;
	}


	public long getMinLoanAmount() {
		return minLoanAmount;
	}


	public void setMinLoanAmount(long minLoanAmount) {
		this.minLoanAmount = minLoanAmount;
	}


	public long getMaxLoanAmount() {
		return maxLoanAmount;
	}


	public void setMaxLoanAmount(long maxLoanAmount) {
		this.maxLoanAmount = maxLoanAmount;
	}


	public float getRateOfInterest() {
		return rateOfInterest;
	}


	public void setRateOfInterest(float rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}


	public String getProofsRequired() {
		return proofsRequired;
	}


	public void setProofsRequired(String proofsRequired) {
		this.proofsRequired = proofsRequired;
	}


	@Override
	public String toString() {
		return " [programName=" + programName
				+ ", description=" + description + ", type=" + type
				+ ", durationInYears=" + durationInYears + ", minLoanAmount="
				+ minLoanAmount + ", maxLoanAmount=" + maxLoanAmount
				+ ", rateOfInterest=" + rateOfInterest + ", proofsRequired="
				+ proofsRequired + "]";
	}
	
	
	
}
