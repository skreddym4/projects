package com.capgemini.laps.bean;

public class ApprovedLoansBean {

	private  String customerName;
	private long amountOfLoanGranted;
	private double monthlyInstallment;
	private int yearsTimePeriod;
	private double downpayment;
	private float rateOfInterest;
	private double totalAmountPayable;
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public long getAmountOfLoanGranted() {
		return amountOfLoanGranted;
	}
	public void setAmountOfLoanGranted(long amountOfLoanGranted) {
		this.amountOfLoanGranted = amountOfLoanGranted;
	}
	public double getMonthlyInstallment() {
		return monthlyInstallment;
	}
	public void setMonthlyInstallment(double monthlyInstallment) {
		this.monthlyInstallment = monthlyInstallment;
	}
	public int getYearsTimePeriod() {
		return yearsTimePeriod;
	}
	public void setYearsTimePeriod(int yearsTimePeriod) {
		this.yearsTimePeriod = yearsTimePeriod;
	}
	public double getDownpayment() {
		return downpayment;
	}
	public void setDownpayment(double downpayment) {
		this.downpayment = downpayment;
	}
	public float getRateOfInterest() {
		return rateOfInterest;
	}
	public void setRateOfInterest(float rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}
	public double getTotalAmountPayable() {
		return totalAmountPayable;
	}
	public void setTotalAmountPayable(double totalAmountPayable) {
		this.totalAmountPayable = totalAmountPayable;
	}
	public ApprovedLoansBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ApprovedLoansBean(String customerName, long amountOfLoanGranted,
			double monthlyInstallment, int yearsTimePeriod, double downpayment,
			float rateOfInterest, double totalAmountPayable) {
		super();
		this.customerName = customerName;
		this.amountOfLoanGranted = amountOfLoanGranted;
		this.monthlyInstallment = monthlyInstallment;
		this.yearsTimePeriod = yearsTimePeriod;
		this.downpayment = downpayment;
		this.rateOfInterest = rateOfInterest;
		this.totalAmountPayable = totalAmountPayable;
	}
	@Override
	public String toString() {
		return "ApprovedLoansBean [customerName=" + customerName
				+ ", amountOfLoanGranted=" + amountOfLoanGranted
				+ ", monthlyInstallment=" + monthlyInstallment
				+ ", yearsTimePeriod=" + yearsTimePeriod + ", downpayment="
				+ downpayment + ", rateOfInterest=" + rateOfInterest
				+ ", totalAmountPayable=" + totalAmountPayable + "]";
	}
	
	
}
