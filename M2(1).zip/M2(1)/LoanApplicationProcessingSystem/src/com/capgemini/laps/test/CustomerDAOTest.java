package com.capgemini.laps.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class CustomerDAOTest {

	@Test
	public void testAddApplicationDetails() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetApplicationStatus() {
		fail("Not yet implemented");
	}

}
