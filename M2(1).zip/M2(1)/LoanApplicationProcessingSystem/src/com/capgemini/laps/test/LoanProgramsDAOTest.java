package com.capgemini.laps.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.laps.dao.ILoanProgramsDAO;
import com.capgemini.laps.dao.LoanProgramsDAO;
import com.capgemini.laps.exception.LoanException;

public class LoanProgramsDAOTest {

	@Test
	public void testLogin() {
		ILoanProgramsDAO dao = new LoanProgramsDAO();
		try {
			assertEquals("admin",dao.login("Admin", "admin"));
		} catch (LoanException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
