package com.capgemini.tcc.exception;

public class PatientProblemException extends Exception {
	private static final long serialVersionUID = 1L;
public int RechargeProblemException(String message) throws PatientProblemException{
		
		return 0;
}}
