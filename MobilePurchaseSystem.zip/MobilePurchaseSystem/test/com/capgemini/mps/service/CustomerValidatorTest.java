package com.capgemini.mps.service;

import static org.junit.Assert.*;

import org.junit.Ignore;
import org.junit.Test;

public class CustomerValidatorTest {

	@Test
	public void testIsValidCustomerName() {
		assertTrue(new CustomerValidator().isValidCustomerName("Srikhar"));
	}
	@Test
	public void testIsNotValidCustomerName() {
		assertFalse(new CustomerValidator().isValidCustomerName("Srikhar xxxxxxxxxxxxxx"));
	}
	
	@Test
	public void testIsValidEmail() {
		assertTrue(new CustomerValidator().isValidEmail("sri@gmail.com"));
	}

	@Test
	public void testIsNotValidEmail() {
		assertFalse(new CustomerValidator().isValidEmail("sri@gmail"));
	}
	
	@Test
	public void testIsValidTelephoneMobile() {
		assertTrue(new CustomerValidator().isValidTelephoneMobile(7799582362L));
	}
	@Test
	public void testIsNotValidTelephoneMobile() {
		assertFalse(new CustomerValidator().isValidTelephoneMobile(5878585L));
	}

}
