package com.capgemini.mps.service;

import java.util.regex.Pattern;


public class CustomerValidator {
	
	public Boolean isValidCustomerName(String name){
		String regex="^[A-Z][a-zA-Z]{1,19}$";
		
		return Pattern.matches(regex, name);
	}
	
	public Boolean isValidEmail(String emailId){
		String regex="^[a-z0-9._]+[@][a-zA-Z]+[.][a-zA-Z]{2,3}$";
		return Pattern.matches(regex, emailId);
	}
	public Boolean isValidTelephoneMobile(Long phoneNumber){
		String mobile=phoneNumber.toString();
		String regex="^[1-9][0-9]{9}$";
		return Pattern.matches(regex, mobile);
	}
	
}
