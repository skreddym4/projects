SQL> create table product(product_code number primary key,product_name varchar2(20),product_category varchar2(20),product_description varchar2(30),product_price number);

Table created.

SQL> insert into product values(1001,'iPhone','Electronics','Smart Phone',35000);

1 row created.

SQL> insert into product values(1002,'LEDTV','Electronics','TV',45000);

1 row created.

SQL> insert into product values(1003,'Teddy','Toys','Soft Toy',800);

1 row created.

SQL> insert into product values(1004,'Pencil','Stationary','A pack of 12 pencils',80);

1 row created.

SQL> create table sales(sales_id number,product_code number references product(product_code),quantity number,sales_date date,line_total number);

Table created.

 create sequence sale_seq start with 100;

Sequence created.
