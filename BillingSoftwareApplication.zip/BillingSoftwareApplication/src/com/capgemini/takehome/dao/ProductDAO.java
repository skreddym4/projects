package com.capgemini.takehome.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.takehome.Exception.TakeHomeException;
import com.capgemini.takehome.bean.ProductBean;
import com.capgemini.takehome.bean.SalesBean;
import com.capgemini.takehome.utility.JdbcUtility;




public class ProductDAO implements IProductDAO {
	static Logger logger = Logger.getLogger(ProductDAO.class);
	Connection connection = null;
	PreparedStatement statement = null;
	@Override
	public ProductBean getProductByCode(int code) throws TakeHomeException {
		logger.info("in getProductByCode method..");


		connection = JdbcUtility.getConnection();
		ProductBean p;
		try{
			statement = connection.prepareStatement(QueryMappers.selectQuery);
			statement.setInt(1, code);

			ResultSet resultSet = statement.executeQuery();
			resultSet.next();
			p=new ProductBean();

			p.setProduct_name(resultSet.getString(2));
			p.setProduct_category(resultSet.getString(3));
			p.setProduct_description(resultSet.getString(4));
			p.setProduct_price(resultSet.getDouble(5));
			//System.out.println(p);
			return p;


		}catch(SQLException e)
		{logger.error("statement not created..");

		throw new TakeHomeException("statement not created");
		}
	}
	@Override
	public Integer buyProducts(SalesBean bean) throws TakeHomeException {
		try(Connection connection=JdbcUtility.getConnection();
			PreparedStatement preparedStatement
				=connection.prepareStatement(QueryMappers.INSERTQUREY);
			Statement statement=connection.createStatement();
				){
			preparedStatement.setInt(1, bean.getProduct_code());
			preparedStatement.setInt(2, bean.getQuantity());
			Date d1= Date.valueOf(bean.getSale_date());
			preparedStatement.setDate(3, d1);
			preparedStatement.setDouble(4, bean.getLine_total());

			int n=preparedStatement.executeUpdate();

			if(n>0){
				ResultSet resultSet 
				= statement.executeQuery(QueryMappers.selectSalesId);
				if(resultSet.next()){
					Integer sales_Id=resultSet.getInt(1);
					bean.setSales_Id(sales_Id);
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return bean.getSales_Id();
	}
	@Override
	public List<ProductBean> getAllProducts() throws TakeHomeException {
		List<ProductBean> list=new ArrayList<ProductBean>();
		try(Connection connection=JdbcUtility.getConnection();
			Statement statement=connection.createStatement();
					){
			ResultSet resultSet=statement.executeQuery(QueryMappers.selectAllQuery);
			while(resultSet.next()){
				ProductBean bean=new ProductBean();
				bean.setProduct_category(resultSet.getString("product_category"));
				bean.setProduct_code(resultSet.getInt("product_code"));
				bean.setProduct_description(resultSet.getString("product_description"));
				bean.setProduct_name(resultSet.getString("product_name"));
				bean.setProduct_price(resultSet.getInt("product_price"));
				
				list.add(bean);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
}




