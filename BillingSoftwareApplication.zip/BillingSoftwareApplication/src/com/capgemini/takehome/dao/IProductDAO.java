package com.capgemini.takehome.dao;

import java.util.List;

import com.capgemini.takehome.Exception.TakeHomeException;
import com.capgemini.takehome.bean.ProductBean;
import com.capgemini.takehome.bean.SalesBean;

public interface IProductDAO {
	
	ProductBean getProductByCode(int code) throws TakeHomeException;
	Integer buyProducts(SalesBean bean) throws TakeHomeException;
	public List<ProductBean> getAllProducts()throws TakeHomeException;

	}

