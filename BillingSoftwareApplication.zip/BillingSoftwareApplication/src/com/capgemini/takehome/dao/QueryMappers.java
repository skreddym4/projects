package com.capgemini.takehome.dao;

public interface QueryMappers {
	public static final String selectQuery = "select * from product where product_code=?";
	public static final String INSERTQUREY = "insert into sales values(sale_seq.nextval,?,?,?,?)";
	public static final String selectSalesId= "select max(sales_Id) from sales";
	public static final String selectAllQuery = "select * from product ";

}
